import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { AnimatePresence } from "framer-motion";
import HeroSearch from "@/components/search/HeroSearch";
import ServiceSelector from "@/components/search/ServiceSelector";
import BudgetStep from "@/components/search/BudgetStep";
import ItineraryResults from "@/components/search/ItineraryResults";
import PopularDestinations from "@/components/hotels/PopularDestinations";
import ThingsToDo from "@/components/hotels/ThingsToDo";
import TopDeals from "@/components/hotels/TopDeals";
import HotelResults from "@/components/hotels/HotelResults";
import TrustBadges from "@/components/hotels/TrustBadges";
import Footer from "@/components/footer/Footer";

export default function Home() {
  const [step, setStep] = useState(1); // 1 = hero, 2 = service selector, 3 = budget, 4 = results
  const [searchParams, setSearchParams] = useState(null);
  const [selectedServices, setSelectedServices] = useState([]);
  const [budget, setBudget] = useState(null);
  const [favorites, setFavorites] = useState(new Set());

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) return;
    const favs = await base44.entities.Favorite.list();
    setFavorites(new Set(favs.map(f => f.hotel_id)));
  };

  const handleToggleFavorite = async (hotel) => {
    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) return;

    const newFavs = new Set(favorites);
    if (newFavs.has(hotel.id)) {
      newFavs.delete(hotel.id);
      // Remove from DB
      const allFavs = await base44.entities.Favorite.filter({ hotel_id: hotel.id });
      if (allFavs.length > 0) {
        await base44.entities.Favorite.delete(allFavs[0].id);
      }
    } else {
      newFavs.add(hotel.id);
      await base44.entities.Favorite.create({
        hotel_id: hotel.id,
        hotel_name: hotel.name,
        hotel_image: hotel.image,
        hotel_location: hotel.location,
        hotel_price: hotel.price,
        hotel_original_price: hotel.originalPrice || null,
        hotel_rating: hotel.rating,
        hotel_reviews: hotel.reviews,
      });
    }
    setFavorites(newFavs);
  };

  const handleSearch = (params) => {
    setSearchParams(params);
    setTimeout(() => {
      document.getElementById("results-section")?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleHeroNext = (params) => {
    setSearchParams(params);
    setStep(2);
    setTimeout(() => {
      document.getElementById("service-selector-section")?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleToggleService = (id) => {
    setSelectedServices(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  const handleServiceNext = () => {
    setStep(3);
    setTimeout(() => {
      document.getElementById("service-selector-section")?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleBudgetSubmit = (b) => {
    setBudget(b);
    setStep(4);
    setTimeout(() => {
      document.getElementById("service-selector-section")?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleReset = () => {
    setStep(1);
    setSelectedServices([]);
    setBudget(null);
  };

  return (
    <div className="min-h-screen bg-white">
      <HeroSearch onSearch={handleSearch} onNext={handleHeroNext} />

      <div id="service-selector-section">
        <AnimatePresence mode="wait">
          {step === 2 && (
            <ServiceSelector
              key="service-selector"
              selected={selectedServices}
              onToggle={handleToggleService}
              onNext={handleServiceNext}
              searchParams={searchParams}
            />
          )}
          {step === 3 && (
            <BudgetStep
              key="budget-step"
              selectedServices={selectedServices}
              searchParams={searchParams}
              onSubmit={handleBudgetSubmit}
            />
          )}
          {step === 4 && (
            <ItineraryResults
              key="itinerary-results"
              selectedServices={selectedServices}
              budget={budget}
              searchParams={searchParams}
              onReset={handleReset}
            />
          )}
        </AnimatePresence>
      </div>

      <div id="results-section">
        <HotelResults
          searchParams={searchParams}
          favorites={favorites}
          onToggleFavorite={handleToggleFavorite}
        />
      </div>
      {step === 4 ? <ThingsToDo /> : <PopularDestinations />}
      <TopDeals favorites={favorites} onToggleFavorite={handleToggleFavorite} />
      <TrustBadges />
      <Footer />
    </div>
  );
}