import React from "react";
import { SlidersHorizontal, Star, DollarSign } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function HotelFilters({ priceFilter, ratingFilter, onPriceChange, onRatingChange }) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="flex items-center gap-1.5 text-sm font-medium text-gray-500">
        <SlidersHorizontal className="w-4 h-4" />
        <span>Filter by:</span>
      </div>

      <Select value={priceFilter} onValueChange={onPriceChange}>
        <SelectTrigger className="w-40 h-10 rounded-xl border-gray-200 text-sm">
          <div className="flex items-center gap-1.5">
            <DollarSign className="w-3.5 h-3.5 text-gray-400" />
            <SelectValue placeholder="Price range" />
          </div>
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All prices</SelectItem>
          <SelectItem value="budget">Under $150</SelectItem>
          <SelectItem value="mid">$150 - $300</SelectItem>
          <SelectItem value="premium">Over $300</SelectItem>
        </SelectContent>
      </Select>

      <Select value={ratingFilter} onValueChange={onRatingChange}>
        <SelectTrigger className="w-40 h-10 rounded-xl border-gray-200 text-sm">
          <div className="flex items-center gap-1.5">
            <Star className="w-3.5 h-3.5 text-gray-400" />
            <SelectValue placeholder="Rating" />
          </div>
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All ratings</SelectItem>
          <SelectItem value="4.5">4.5+ Stars</SelectItem>
          <SelectItem value="4.0">4.0+ Stars</SelectItem>
          <SelectItem value="3.5">3.5+ Stars</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}