import React from "react";
import { Zap } from "lucide-react";
import HotelCard from "./HotelCard";

const deals = [
  {
    id: "1",
    name: "Luxury Beach Resort",
    location: "Maldives",
    image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=600&q=80",
    rating: 4.8,
    reviews: 2847,
    price: 279,
    originalPrice: 399,
    discount: "-30%",
  },
  {
    id: "2",
    name: "Northern Lights Experience",
    location: "Iceland",
    image: "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=600&q=80",
    rating: 4.6,
    reviews: 891,
    price: 189,
    originalPrice: 299,
    discount: "-37%",
  },
  {
    id: "3",
    name: "5-Star City Hotel",
    location: "New York",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&q=80",
    rating: 4.7,
    reviews: 3104,
    price: 219,
    originalPrice: 349,
    discount: "-37%",
  },
  {
    id: "4",
    name: "Tropical Paradise Villa",
    location: "Bali",
    image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&q=80",
    rating: 4.9,
    reviews: 1567,
    price: 159,
    originalPrice: 249,
    discount: "-36%",
  },
  {
    id: "5",
    name: "Alpine Ski Lodge",
    location: "Switzerland",
    image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600&q=80",
    rating: 4.5,
    reviews: 742,
    price: 299,
    originalPrice: 450,
    discount: "-34%",
  },
  {
    id: "6",
    name: "Historic Boutique Hotel",
    location: "Rome",
    image: "https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=600&q=80",
    rating: 4.4,
    reviews: 1893,
    price: 139,
    originalPrice: 199,
    discount: "-30%",
  },
];

export default function TopDeals({ favorites, onToggleFavorite }) {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      <div className="flex items-center gap-2 mb-8">
        <Zap className="w-5 h-5 text-[#f5a623]" />
        <h2 className="text-2xl font-bold text-gray-900">Today's top deals</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {deals.map((hotel) => (
          <HotelCard
            key={hotel.id}
            hotel={hotel}
            isFavorited={favorites.has(hotel.id)}
            onToggleFavorite={onToggleFavorite}
          />
        ))}
      </div>
    </section>
  );
}