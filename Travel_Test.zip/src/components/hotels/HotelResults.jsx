import React, { useState } from "react";
import { Search as SearchIcon, SlidersHorizontal } from "lucide-react";
import HotelCard from "./HotelCard";
import HotelSidebar from "./HotelSidebar";
import HotelCompareBar from "./HotelCompareBar";
import HotelCompareModal from "./HotelCompareModal";
import { AnimatePresence, motion } from "framer-motion";

export const allHotels = [
  {
    id: "r1",
    name: "Grand Oceanfront Resort",
    location: "Miami, USA",
    district: "Beachfront • 0.2 mi from center",
    image: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=600&q=80",
    rating: 4.7,
    reviews: 2103,
    price: 245,
    originalPrice: 320,
    stars: 5,
    amenities: { wifi: true, pool: true, breakfast: true, parking: false, fitness: true, spa: false },
    roomTypes: ["King Suite", "Double Room", "Ocean View"],
    nearbyAttractions: ["South Beach (0.2 mi)", "Art Deco District (1.1 mi)", "Bayside Marketplace (3 mi)"],
  },
  {
    id: "r2",
    name: "Sakura Garden Hotel",
    location: "Tokyo, Japan",
    district: "Shinjuku District • 0.5 mi from center",
    image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=600&q=80",
    rating: 4.5,
    reviews: 987,
    price: 175,
    originalPrice: null,
    stars: 4,
    amenities: { wifi: true, pool: false, breakfast: true, parking: true, fitness: true, spa: false },
    roomTypes: ["Standard Room", "Japanese Suite", "Garden View"],
    nearbyAttractions: ["Shinjuku Park (0.5 mi)", "Meiji Shrine (1.2 mi)", "Harajuku (2 mi)"],
  },
  {
    id: "r3",
    name: "The Royal Palace",
    location: "London, UK",
    district: "Mayfair • 0.3 mi from center",
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=600&q=80",
    rating: 4.9,
    reviews: 4521,
    price: 389,
    originalPrice: 499,
    stars: 5,
    amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: true },
    roomTypes: ["Deluxe Room", "Royal Suite", "Family Room"],
    nearbyAttractions: ["Hyde Park (0.3 mi)", "Buckingham Palace (0.8 mi)", "Big Ben (1.5 mi)"],
  },
  {
    id: "r4",
    name: "Desert Oasis Retreat",
    location: "Dubai, UAE",
    district: "Downtown Dubai • 1.0 mi from center",
    image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=600&q=80",
    rating: 4.6,
    reviews: 1345,
    price: 310,
    originalPrice: 420,
    stars: 5,
    amenities: { wifi: true, pool: true, breakfast: false, parking: true, fitness: true, spa: true },
    roomTypes: ["Desert View Suite", "Luxury Villa", "Pool Room"],
    nearbyAttractions: ["Dubai Mall (1 mi)", "Burj Khalifa (1.1 mi)", "Dubai Fountain (1.2 mi)"],
  },
  {
    id: "r5",
    name: "Riverside Boutique Inn",
    location: "Paris, France",
    district: "7th Arrondissement • 0.4 mi from center",
    image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=600&q=80",
    rating: 4.3,
    reviews: 678,
    price: 135,
    originalPrice: null,
    stars: 3,
    amenities: { wifi: true, pool: false, breakfast: true, parking: false, fitness: false, spa: false },
    roomTypes: ["Cozy Room", "River View", "Romantic Suite"],
    nearbyAttractions: ["Eiffel Tower (0.4 mi)", "Champ de Mars (0.5 mi)", "Musée d'Orsay (1 mi)"],
  },
  {
    id: "r6",
    name: "Mountain View Lodge",
    location: "Queenstown, NZ",
    district: "Lakefront • 0.1 mi from center",
    image: "https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=600&q=80",
    rating: 4.8,
    reviews: 892,
    price: 265,
    originalPrice: 350,
    stars: 4,
    amenities: { wifi: true, pool: false, breakfast: true, parking: true, fitness: true, spa: false },
    roomTypes: ["Mountain Suite", "Lake View Room", "Chalet"],
    nearbyAttractions: ["Lake Wakatipu (0.1 mi)", "Skyline Gondola (0.5 mi)", "Milford Sound (2 hrs)"],
  },
];

export default function HotelResults({ searchParams, favorites, onToggleFavorite }) {
  const [maxPrice, setMaxPrice] = useState(500);
  const [starsFilter, setStarsFilter] = useState([]);
  const [amenityFilters, setAmenityFilters] = useState([]);
  const [sortBy, setSortBy] = useState("recommended");
  const [searchQuery, setSearchQuery] = useState("");
  const [compareList, setCompareList] = useState([]);
  const [showCompare, setShowCompare] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleStar = (s) =>
    setStarsFilter((prev) => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  const toggleAmenity = (a) =>
    setAmenityFilters((prev) => prev.includes(a) ? prev.filter(x => x !== a) : [...prev, a]);

  const toggleCompare = (hotel) => {
    setCompareList((prev) => {
      if (prev.find(h => h.id === hotel.id)) return prev.filter(h => h.id !== hotel.id);
      if (prev.length >= 3) return prev;
      return [...prev, hotel];
    });
  };

  const filteredHotels = allHotels
    .filter((hotel) => {
      if (hotel.price > maxPrice) return false;
      if (starsFilter.length > 0 && !starsFilter.includes(hotel.stars)) return false;
      if (amenityFilters.length > 0 && !amenityFilters.every(a => hotel.amenities[a])) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (!hotel.name.toLowerCase().includes(q) && !hotel.location.toLowerCase().includes(q)) return false;
      }
      if (searchParams?.destination) {
        const dest = searchParams.destination.toLowerCase();
        if (!hotel.location.toLowerCase().includes(dest) && !hotel.name.toLowerCase().includes(dest)) return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "price_asc") return a.price - b.price;
      if (sortBy === "price_desc") return b.price - a.price;
      if (sortBy === "rating") return b.rating - a.rating;
      return 0;
    });

  if (!searchParams?.destination) return null;

  return (
    <section className="bg-[#f7f9fc] min-h-screen pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Find Your Perfect Hotel</h2>
          <span className="text-sm text-gray-500">{filteredHotels.length} hotels available</span>
        </div>
      </div>

      {/* Search + Sort bar */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-8 py-3 sticky top-16 z-20">
        <div className="max-w-7xl mx-auto flex items-center gap-3">
          <div className="flex-1 flex items-center gap-2 border border-gray-200 rounded-lg px-3 py-2 bg-white">
            <SearchIcon className="w-4 h-4 text-gray-400 shrink-0" />
            <input
              type="text"
              placeholder="Search by hotel name or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 text-sm outline-none bg-transparent text-gray-700 placeholder-gray-400"
            />
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white focus:outline-none shrink-0"
          >
            <option value="recommended">Sort: Recommended</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="flex items-center gap-1.5 sm:hidden text-sm font-semibold text-[#0c3b8f] border border-[#0c3b8f] rounded-lg px-3 py-2"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 flex gap-6">
        {/* Desktop Sidebar */}
        <div className="shrink-0 w-56 hidden sm:block">
          <HotelSidebar
            maxPrice={maxPrice} setMaxPrice={setMaxPrice}
            starsFilter={starsFilter} toggleStar={toggleStar}
            amenityFilters={amenityFilters} toggleAmenity={toggleAmenity}
          />
        </div>

        {/* Mobile Sidebar */}
        <AnimatePresence>
          {sidebarOpen && (
            <motion.div
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              className="fixed inset-0 z-40 sm:hidden"
            >
              <div className="absolute inset-0 bg-black/40" onClick={() => setSidebarOpen(false)} />
              <div className="absolute left-0 top-0 bottom-0 w-72 bg-white overflow-y-auto p-4">
                <HotelSidebar
                  maxPrice={maxPrice} setMaxPrice={setMaxPrice}
                  starsFilter={starsFilter} toggleStar={toggleStar}
                  amenityFilters={amenityFilters} toggleAmenity={toggleAmenity}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Cards Grid */}
        <div className="flex-1 min-w-0">
          {filteredHotels.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              <AnimatePresence>
                {filteredHotels.map((hotel) => (
                  <HotelCard
                    key={hotel.id}
                    hotel={hotel}
                    isFavorited={favorites?.has(hotel.id)}
                    onToggleFavorite={onToggleFavorite}
                    isCompared={!!compareList.find(h => h.id === hotel.id)}
                    onToggleCompare={toggleCompare}
                    compareDisabled={compareList.length >= 3 && !compareList.find(h => h.id === hotel.id)}
                  />
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="text-center py-20">
              <SearchIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-500">No hotels match your filters</p>
              <p className="text-sm text-gray-400 mt-1">Try adjusting your search or filters</p>
            </div>
          )}
        </div>
      </div>

      {/* Compare Bar */}
      <AnimatePresence>
        {compareList.length >= 1 && (
          <HotelCompareBar
            compareList={compareList}
            onRemove={(id) => setCompareList(prev => prev.filter(h => h.id !== id))}
            onCompare={() => setShowCompare(true)}
            onClear={() => setCompareList([])}
          />
        )}
      </AnimatePresence>

      {/* Compare Modal */}
      <AnimatePresence>
        {showCompare && (
          <HotelCompareModal
            hotels={compareList}
            onClose={() => setShowCompare(false)}
          />
        )}
      </AnimatePresence>
    </section>
  );
}