import React from "react";
import { BadgeCheck, Star, Building2 } from "lucide-react";
import { motion } from "framer-motion";

const badges = [
  {
    icon: BadgeCheck,
    title: "Best price guarantee",
    description: "Find it lower? We'll refund the difference",
  },
  {
    icon: Star,
    title: "Verified reviews",
    description: "Over 10 million authentic guest reviews",
  },
  {
    icon: Building2,
    title: "Millions of properties",
    description: "Hotels, homes, and resorts in 200+ countries",
  },
];

export default function TrustBadges() {
  return (
    <section className="bg-gray-50/80 border-y border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
          {badges.map((badge, index) => (
            <motion.div
              key={badge.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.4 }}
              className="flex flex-col items-center text-center"
            >
              <div className="w-12 h-12 rounded-2xl bg-[#0c3b8f]/5 flex items-center justify-center mb-4">
                <badge.icon className="w-6 h-6 text-[#0c3b8f]" />
              </div>
              <h3 className="font-bold text-sm text-gray-900">{badge.title}</h3>
              <p className="text-xs text-gray-500 mt-1.5 max-w-[220px] leading-relaxed">{badge.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}