import React from "react";
import { motion } from "framer-motion";
import { X, Star, MapPin, Wifi, Waves, Coffee, ParkingCircle, CheckCircle2, XCircle } from "lucide-react";

const ROW_LABELS = [
  { key: "price", label: "Price / night" },
  { key: "rating", label: "Guest Rating" },
  { key: "stars", label: "Hotel Stars" },
  { key: "distance", label: "Distance to Area" },
  { key: "wifi", label: "Free WiFi" },
  { key: "pool", label: "Swimming Pool" },
  { key: "breakfast", label: "Breakfast" },
  { key: "parking", label: "Free Parking" },
  { key: "roomTypes", label: "Room Types" },
  { key: "attractions", label: "Nearby Attractions" },
];

const getVal = (hotel, key) => {
  if (key === "price") return `$${hotel.price}/night`;
  if (key === "rating") return (
    <span className="flex items-center gap-1">
      <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
      <strong>{hotel.rating}</strong>
      <span className="text-xs text-gray-400">({hotel.reviews.toLocaleString()})</span>
    </span>
  );
  if (key === "stars") return (
    <span className="flex gap-0.5">
      {Array.from({ length: hotel.stars }).map((_, i) => (
        <Star key={i} className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
      ))}
    </span>
  );
  if (key === "distance") return hotel.distance;
  if (["wifi", "pool", "breakfast", "parking"].includes(key)) {
    return hotel.amenities[key]
      ? <CheckCircle2 className="w-5 h-5 text-green-500 mx-auto" />
      : <XCircle className="w-5 h-5 text-red-300 mx-auto" />;
  }
  if (key === "roomTypes") return (
    <ul className="space-y-0.5">
      {hotel.roomTypes.map((r, i) => <li key={i} className="text-xs text-gray-600">• {r}</li>)}
    </ul>
  );
  if (key === "attractions") return (
    <ul className="space-y-0.5">
      {hotel.nearbyAttractions.map((a, i) => <li key={i} className="text-xs text-gray-600">📍 {a}</li>)}
    </ul>
  );
  return "—";
};

const isBest = (hotels, key) => {
  if (key === "price") return hotels.reduce((a, b) => a.price < b.price ? a : b).id;
  if (key === "rating") return hotels.reduce((a, b) => a.rating > b.rating ? a : b).id;
  if (key === "stars") return hotels.reduce((a, b) => a.stars > b.stars ? a : b).id;
  return null;
};

export default function HotelCompareModal({ hotels, onClose }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 shrink-0">
          <div>
            <h2 className="text-lg font-bold text-gray-900">Hotel Comparison</h2>
            <p className="text-xs text-gray-400">Comparing {hotels.length} hotels side-by-side</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-100 transition-colors">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="overflow-auto flex-1">
          <table className="w-full border-collapse min-w-[600px]">
            <thead>
              <tr>
                <th className="text-left px-5 py-3 bg-gray-50 text-xs font-bold text-gray-500 uppercase tracking-wider w-36 border-b border-gray-100 sticky left-0 z-10"></th>
                {hotels.map((hotel) => (
                  <th key={hotel.id} className="px-4 py-3 bg-gray-50 border-b border-gray-100 min-w-[180px]">
                    <div className="flex flex-col items-center gap-2">
                      <img src={hotel.image} alt={hotel.name} className="w-full h-28 object-cover rounded-xl" />
                      <p className="text-sm font-bold text-gray-900 text-center leading-tight">{hotel.name}</p>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <MapPin className="w-3 h-3" />
                        {hotel.location}
                      </div>
                      <button className="w-full bg-[#0c3b8f] hover:bg-[#072a66] text-white text-xs font-bold py-1.5 rounded-lg transition-colors">
                        View Details
                      </button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ROW_LABELS.map((row, ri) => {
                const bestId = isBest(hotels, row.key);
                return (
                  <tr key={row.key} className={ri % 2 === 0 ? "bg-white" : "bg-gray-50/50"}>
                    <td className="px-5 py-3.5 text-xs font-semibold text-gray-500 border-r border-gray-100 sticky left-0 bg-inherit z-10">
                      {row.label}
                    </td>
                    {hotels.map((hotel) => {
                      const highlight = bestId === hotel.id;
                      return (
                        <td key={hotel.id} className={`px-4 py-3.5 text-sm text-gray-800 border-r border-gray-100 last:border-r-0 text-center align-middle ${highlight ? "bg-blue-50" : ""}`}>
                          {highlight && (
                            <div className="text-[10px] font-bold text-[#0c3b8f] mb-1 uppercase tracking-wide">Best</div>
                          )}
                          {getVal(hotel, row.key)}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
}