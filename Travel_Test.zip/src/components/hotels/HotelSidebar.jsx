import React from "react";
import { Wifi, ParkingCircle, Coffee, Waves, Star, Dumbbell, Zap } from "lucide-react";

const AMENITIES = [
  { id: "wifi", label: "Free WiFi", icon: Wifi },
  { id: "breakfast", label: "Breakfast", icon: Coffee },
  { id: "parking", label: "Parking", icon: ParkingCircle },
  { id: "fitness", label: "Fitness Center", icon: Dumbbell },
  { id: "pool", label: "Swimming Pool", icon: Waves },
  { id: "spa", label: "Spa", icon: Zap },
];

const STAR_OPTIONS = [5, 4, 3];

export default function HotelSidebar({
  maxPrice, setMaxPrice,
  starsFilter, toggleStar,
  amenityFilters, toggleAmenity,
}) {
  return (
    <aside className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-6 sticky top-28">
      <h3 className="text-base font-bold text-gray-900">Filters</h3>

      {/* Price Slider */}
      <div>
        <p className="text-sm font-semibold text-gray-800 mb-3">Price per Night</p>
        <input
          type="range"
          min={0}
          max={500}
          step={10}
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="w-full accent-[#0c3b8f] cursor-pointer"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>$0</span>
          <span className="font-semibold text-[#0c3b8f]">${maxPrice}</span>
          <span>$500</span>
        </div>
      </div>

      <div className="border-t border-gray-100" />

      {/* Star Rating */}
      <div>
        <p className="text-sm font-semibold text-gray-800 mb-3">Star Rating</p>
        <div className="space-y-2.5">
          {STAR_OPTIONS.map((s) => (
            <label key={s} className="flex items-center gap-2.5 cursor-pointer group">
              <input
                type="checkbox"
                checked={starsFilter.includes(s)}
                onChange={() => toggleStar(s)}
                className="accent-[#0c3b8f] w-4 h-4 rounded"
              />
              <span className="flex items-center gap-1">
                {Array.from({ length: s }).map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                ))}
              </span>
              <span className="text-sm text-gray-600 group-hover:text-gray-900">& up</span>
            </label>
          ))}
        </div>
      </div>

      <div className="border-t border-gray-100" />

      {/* Amenities */}
      <div>
        <p className="text-sm font-semibold text-gray-800 mb-3">Amenities</p>
        <div className="space-y-2.5">
          {AMENITIES.map(({ id, label, icon: Icon }) => (
            <label key={id} className="flex items-center gap-2.5 cursor-pointer group">
              <input
                type="checkbox"
                checked={amenityFilters.includes(id)}
                onChange={() => toggleAmenity(id)}
                className="accent-[#0c3b8f] w-4 h-4 rounded"
              />
              <Icon className="w-3.5 h-3.5 text-gray-400 shrink-0" />
              <span className={`text-sm transition-colors ${amenityFilters.includes(id) ? "text-[#0c3b8f] font-semibold" : "text-gray-600 group-hover:text-gray-900"}`}>
                {label}
              </span>
            </label>
          ))}
        </div>
      </div>

      <div className="border-t border-gray-100" />

      {/* Distance */}
      <div>
        <p className="text-sm font-semibold text-gray-800 mb-3">Distance from Center</p>
        <input
          type="range"
          min={1}
          max={20}
          defaultValue={10}
          className="w-full accent-[#0c3b8f] cursor-pointer"
        />
        <p className="text-xs text-gray-500 mt-1">Within 10 miles</p>
      </div>
    </aside>
  );
}