import React from "react";
import { motion } from "framer-motion";
import { X, GitCompare } from "lucide-react";

export default function HotelCompareBar({ compareList, onRemove, onCompare, onClear }) {
  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 100, opacity: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="fixed bottom-0 left-0 right-0 z-30 bg-white border-t-2 border-[#0c3b8f] shadow-[0_-4px_24px_rgba(0,0,0,0.12)]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center gap-4">
        <div className="flex items-center gap-1.5 shrink-0">
          <GitCompare className="w-4 h-4 text-[#0c3b8f]" />
          <span className="text-sm font-bold text-gray-900">Compare Hotels</span>
          <span className="text-xs text-gray-400">({compareList.length}/3 selected)</span>
        </div>

        <div className="flex items-center gap-3 flex-1 overflow-x-auto">
          {compareList.map((hotel) => (
            <div key={hotel.id} className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-lg px-3 py-1.5 shrink-0">
              <img src={hotel.image} alt={hotel.name} className="w-8 h-8 rounded object-cover" />
              <span className="text-xs font-semibold text-gray-800 max-w-[100px] truncate">{hotel.name}</span>
              <button onClick={() => onRemove(hotel.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
          {Array.from({ length: 3 - compareList.length }).map((_, i) => (
            <div key={i} className="flex items-center justify-center w-28 h-10 border-2 border-dashed border-gray-200 rounded-lg shrink-0">
              <span className="text-xs text-gray-300">+ Add hotel</span>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onClear}
            className="text-xs text-gray-400 hover:text-gray-600 font-medium transition-colors"
          >
            Clear
          </button>
          <button
            onClick={onCompare}
            disabled={compareList.length < 2}
            className="bg-[#0c3b8f] hover:bg-[#072a66] disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-bold px-5 py-2 rounded-lg transition-all duration-200"
          >
            Compare Now →
          </button>
        </div>
      </div>
    </motion.div>
  );
}