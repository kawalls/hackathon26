import React from "react";
import { Star, MapPin, Heart, Wifi, ParkingCircle, Coffee, Waves, Dumbbell, Zap, GitCompare } from "lucide-react";
import { motion } from "framer-motion";

const AMENITY_ICONS = [
  { key: "wifi", icon: Wifi },
  { key: "pool", icon: Waves },
  { key: "breakfast", icon: Coffee },
  { key: "parking", icon: ParkingCircle },
  { key: "fitness", icon: Dumbbell },
  { key: "spa", icon: Zap },
];

export default function HotelCard({ hotel, isFavorited, onToggleFavorite, isCompared, onToggleCompare, compareDisabled }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.25 }}
      className={`bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border-2 flex flex-col ${isCompared ? "border-[#0c3b8f]" : "border-gray-100"}`}
    >
      {/* Image */}
      <div className="relative h-48 overflow-hidden shrink-0">
        <img
          src={hotel.image}
          alt={hotel.name}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
        />
        {/* Price badge */}
        <div className="absolute top-3 right-3 bg-[#0c3b8f] text-white text-sm font-bold px-3 py-1 rounded-lg shadow">
          ${hotel.price}/night
        </div>
        {/* Favorite */}
        <button
          onClick={(e) => { e.stopPropagation(); onToggleFavorite?.(hotel); }}
          className={`absolute top-3 left-3 p-1.5 rounded-full backdrop-blur-md transition-all duration-200 ${
            isFavorited ? "bg-red-500 text-white" : "bg-white/80 text-gray-500 hover:text-red-500"
          }`}
        >
          <Heart className={`w-4 h-4 ${isFavorited ? "fill-current" : ""}`} />
        </button>
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1">
        {/* Name */}
        <h3 className="font-bold text-base text-gray-900 leading-tight">{hotel.name}</h3>

        {/* Location */}
        <div className="flex items-start gap-1 mt-1">
          <MapPin className="w-3.5 h-3.5 text-gray-400 mt-0.5 shrink-0" />
          <span className="text-xs text-gray-500">{hotel.district || hotel.location}</span>
        </div>

        {/* Star rating row */}
        <div className="flex items-center gap-2 mt-2.5">
          <div className="flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className={`w-3.5 h-3.5 ${i < Math.round(hotel.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-200 fill-gray-200"}`} />
            ))}
          </div>
          <span className="text-xs font-semibold text-gray-700">{hotel.rating}</span>
          <span className="text-xs text-gray-400">({hotel.reviews.toLocaleString()} reviews)</span>
        </div>

        {/* Amenity icons */}
        <div className="flex items-center gap-3 mt-3 pt-3 border-t border-gray-100">
          {AMENITY_ICONS.map(({ key, icon: Icon }) => (
            <Icon
              key={key}
              className={`w-4 h-4 ${hotel.amenities?.[key] ? "text-gray-500" : "text-gray-200"}`}
              title={key}
            />
          ))}
        </div>

        {/* Room types */}
        <p className="text-xs text-gray-500 mt-2.5">
          {hotel.roomTypes?.length} room types available
        </p>

        {/* Buttons */}
        <div className="flex items-center gap-2 mt-3">
          <button className="flex-1 bg-[#0c3b8f] hover:bg-[#072a66] text-white text-sm font-bold py-2.5 rounded-lg transition-all duration-200">
            View Details
          </button>
          <button
            onClick={() => onToggleCompare?.(hotel)}
            disabled={compareDisabled}
            title="Compare"
            className={`p-2.5 rounded-lg border transition-all duration-200 ${
              isCompared
                ? "bg-[#0c3b8f]/10 border-[#0c3b8f] text-[#0c3b8f]"
                : compareDisabled
                ? "border-gray-200 text-gray-300 cursor-not-allowed"
                : "border-gray-200 text-gray-500 hover:border-[#0c3b8f] hover:text-[#0c3b8f]"
            }`}
          >
            <GitCompare className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}