import React from "react";
import { Compass, Users, CalendarPlus } from "lucide-react";
import { motion } from "framer-motion";

const activities = [
  { name: "City Food Tour", category: "Food & Drink", image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600&q=80", participants: "12k+ joined" },
  { name: "Sunset Sailing", category: "Water Sports", image: "https://images.unsplash.com/photo-1500514966906-fe245eea9344?w=600&q=80", participants: "8k+ joined" },
  { name: "Museum Hopping", category: "Culture & Arts", image: "https://images.unsplash.com/photo-1554907984-15263bfd63bd?w=600&q=80", participants: "15k+ joined" },
  { name: "Hiking Adventure", category: "Outdoors", image: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=600&q=80", participants: "20k+ joined" },
  { name: "Spa Day Retreat", category: "Wellness", image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=600&q=80", participants: "6k+ joined" },
  { name: "Night Market Walk", category: "Shopping", image: "https://images.unsplash.com/photo-1533900298318-6b8da08a523e?w=600&q=80", participants: "18k+ joined" },
];

export default function ThingsToDo() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      <div className="flex items-center gap-2 mb-8">
        <Compass className="w-5 h-5 text-[#0c3b8f]" />
        <h2 className="text-2xl font-bold text-gray-900">Things to do</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {activities.map((activity, index) => (
          <motion.div
            key={activity.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.08, duration: 0.4 }}
            whileHover={{ y: -4 }}
            className="relative h-44 rounded-2xl overflow-hidden cursor-pointer group shadow-[0_2px_16px_rgba(0,0,0,0.06)] hover:shadow-[0_8px_32px_rgba(0,0,0,0.15)] transition-shadow duration-300"
          >
            <img
              src={activity.image}
              alt={activity.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-white font-bold text-lg leading-tight">{activity.name}</h3>
              <p className="text-white/70 text-sm">{activity.category}</p>
            </div>
            <div className="absolute bottom-4 right-4 flex items-center gap-1 text-white/70">
              <Users className="w-3.5 h-3.5" />
              <span className="text-xs font-medium">{activity.participants}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-10 flex justify-center">
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="flex items-center gap-2.5 bg-[#0c3b8f] hover:bg-[#072a66] text-white font-bold text-base px-8 py-3.5 rounded-xl shadow-md transition-colors duration-200"
        >
          <CalendarPlus className="w-5 h-5" />
          Make Itinerary
        </motion.button>
      </div>
    </section>
  );
}