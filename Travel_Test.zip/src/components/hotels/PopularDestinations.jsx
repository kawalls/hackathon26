import React from "react";
import { TrendingUp, Building2 } from "lucide-react";
import { motion } from "framer-motion";

const destinations = [
  { name: "Paris", country: "France", image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&q=80", properties: 3481 },
  { name: "Tokyo", country: "Japan", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600&q=80", properties: 1893 },
  { name: "New York", country: "United States", image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=600&q=80", properties: 3174 },
  { name: "Dubai", country: "UAE", image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&q=80", properties: 1987 },
  { name: "London", country: "United Kingdom", image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=600&q=80", properties: 2783 },
  { name: "Bali", country: "Indonesia", image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=600&q=80", properties: 1238 },
];

export default function PopularDestinations() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      <div className="flex items-center gap-2 mb-8">
        <TrendingUp className="w-5 h-5 text-[#0c3b8f]" />
        <h2 className="text-2xl font-bold text-gray-900">Popular destinations</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {destinations.map((dest, index) => (
          <motion.div
            key={dest.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.08, duration: 0.4 }}
            whileHover={{ y: -4 }}
            className="relative h-44 rounded-2xl overflow-hidden cursor-pointer group shadow-[0_2px_16px_rgba(0,0,0,0.06)] hover:shadow-[0_8px_32px_rgba(0,0,0,0.15)] transition-shadow duration-300"
          >
            <img
              src={dest.image}
              alt={dest.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-white font-bold text-lg leading-tight">{dest.name}</h3>
              <p className="text-white/70 text-sm">{dest.country}</p>
            </div>
            <div className="absolute bottom-4 right-4 flex items-center gap-1 text-white/70">
              <Building2 className="w-3.5 h-3.5" />
              <span className="text-xs font-medium">{dest.properties.toLocaleString()} properties</span>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}