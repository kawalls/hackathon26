import React, { useState, useRef, useEffect } from "react";
import { Search, MapPin, CalendarDays, Users } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarWidget } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";

export default function HeroSearch({ onSearch, onNext }) {
  const [destination, setDestination] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [checkIn, setCheckIn] = useState(null);
  const [checkOut, setCheckOut] = useState(null);
  const [travelers, setTravelers] = useState("2");
  const inputRef = useRef(null);
  const debounceRef = useRef(null);

  const handleDestinationChange = (e) => {
    const val = e.target.value;
    setDestination(val);
    if (val.trim().length < 2) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(val)}&format=json&limit=6&addressdetails=1`,
          { headers: { "Accept-Language": "en" } }
        );
        const data = await res.json();
        const places = data.map(item => item.display_name);
        setSuggestions(places);
        setShowSuggestions(places.length > 0);
      } catch {
        setSuggestions([]);
        setShowSuggestions(false);
      }
    }, 300);
  };

  const handleSelectSuggestion = (place) => {
    setDestination(place);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handleSearch = () => {
    setShowSuggestions(false);
    const params = { destination, checkIn, checkOut, travelers };
    onSearch?.(params);
    onNext?.(params);
  };

  const travelersLabel = `${travelers} traveler${Number(travelers) > 1 ? "s" : ""}`;

  return (
    <div className="relative">
      {/* Hero Background */}
      <div className="relative h-[400px] sm:h-[420px] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center scale-105"
          style={{
            backgroundImage: "url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69ac8c954987d73747ea3c4c/8c0cf7ab7_generated_image.png')",
            animation: "subtleDrift 20s ease-in-out infinite alternate",
          }}
        />
        <style>{`
          @keyframes subtleDrift {
            from { transform: scale(1.05) translateX(0px); }
            to   { transform: scale(1.08) translateX(-20px); }
          }
        `}</style>
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/60" />

        <div className="relative z-10 flex flex-col items-center justify-center h-full text-white px-4 pt-10">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center leading-tight tracking-tight drop-shadow-lg">
            Explore the world with us
          </h1>
          <p className="mt-3 text-base sm:text-lg text-white/80 text-center max-w-lg mb-8">
            Discover your next adventure at the best prices
          </p>

          {/* Search Bar */}
          <div className="w-full max-w-4xl px-4">
            <div className="flex flex-col sm:flex-row items-stretch gap-0 bg-white rounded-2xl shadow-[0_8px_40px_rgba(0,0,0,0.25)] overflow-visible">

              {/* Destination */}
              <div className="relative flex items-center gap-3 px-4 py-3 flex-1 border-b sm:border-b-0 sm:border-r border-gray-200 hover:bg-gray-50/50 transition-colors rounded-l-2xl">
                <MapPin className="w-4 h-4 text-gray-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-semibold text-gray-500">Where to?</p>
                  <input
                    ref={inputRef}
                    type="text"
                    placeholder="Search destinations..."
                    value={destination}
                    onChange={handleDestinationChange}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
                    onFocus={() => destination && suggestions.length > 0 && setShowSuggestions(true)}
                    className="bg-transparent text-sm font-medium text-gray-800 placeholder-gray-400 outline-none w-full"
                  />
                </div>
                {showSuggestions && suggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden">
                    {suggestions.map((place) => (
                      <button
                        key={place}
                        onMouseDown={() => handleSelectSuggestion(place)}
                        className="flex items-center gap-3 w-full px-4 py-2.5 hover:bg-gray-50 text-left transition-colors"
                      >
                        <MapPin className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                        <span className="text-sm text-gray-700">{place}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Dates (combined) */}
              <Popover>
                <PopoverTrigger asChild>
                  <button className="flex items-center gap-3 px-4 py-3 flex-1 border-b sm:border-b-0 sm:border-r border-gray-200 hover:bg-gray-50/50 transition-colors text-left w-full">
                    <CalendarDays className="w-4 h-4 text-gray-400 shrink-0" />
                    <div>
                      <p className="text-[10px] font-semibold text-gray-500">Dates</p>
                      <p className={`text-sm font-medium ${(checkIn || checkOut) ? "text-gray-800" : "text-gray-400"}`}>
                        {checkIn && checkOut
                          ? `${format(checkIn, "EEE, MMM d")} - ${format(checkOut, "EEE, MMM d")}`
                          : checkIn
                          ? `${format(checkIn, "EEE, MMM d")} - Check-out`
                          : "Add dates"}
                      </p>
                    </div>
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-3" align="start">
                  <div className="flex gap-2">
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-1 px-1">Check-in</p>
                      <CalendarWidget mode="single" selected={checkIn} onSelect={setCheckIn} />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-gray-500 mb-1 px-1">Check-out</p>
                      <CalendarWidget mode="single" selected={checkOut} onSelect={setCheckOut} />
                    </div>
                  </div>
                </PopoverContent>
              </Popover>

              {/* Travelers & Rooms */}
              <Popover>
                <PopoverTrigger asChild>
                  <button className="flex items-center gap-3 px-4 py-3 flex-1 border-b sm:border-b-0 border-gray-200 hover:bg-gray-50/50 transition-colors text-left w-full">
                    <Users className="w-4 h-4 text-gray-400 shrink-0" />
                    <div>
                      <p className="text-[10px] font-semibold text-gray-500">Travelers</p>
                      <p className="text-sm font-medium text-gray-800">{travelersLabel}</p>
                    </div>
                  </button>
                </PopoverTrigger>
                <PopoverContent className="w-56 p-4" align="end">
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs font-bold text-gray-600 uppercase tracking-wider block mb-2">Travelers</label>
                      <Select value={travelers} onValueChange={setTravelers}>
                        <SelectTrigger className="h-10 rounded-lg"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {[1,2,3,4,5,6].map(n => (
                            <SelectItem key={n} value={String(n)}>{n} traveler{n > 1 ? "s" : ""}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                  </div>
                </PopoverContent>
              </Popover>

              {/* Search Button */}
              <button
                onClick={handleSearch}
                className="flex items-center justify-center gap-2 bg-[#0c3b8f] hover:bg-[#072a66] text-white font-bold text-sm px-6 py-3 m-1.5 rounded-xl shadow-lg transition-all duration-200 hover:scale-[1.02] shrink-0"
              >
                <Search className="w-4 h-4" />
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}