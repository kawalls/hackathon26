import React, { useState } from "react";
import { motion } from "framer-motion";
import { DollarSign } from "lucide-react";

const BUDGET_PRESETS = [500, 1000, 2000, 3500, 5000, 10000];

export default function BudgetStep({ selectedServices, searchParams, onSubmit }) {
  const [budget, setBudget] = useState("");
  const [custom, setCustom] = useState(false);

  const handlePreset = (amount) => {
    setBudget(String(amount));
    setCustom(false);
  };

  const handleSubmit = () => {
    const b = parseFloat(budget);
    if (!isNaN(b) && b > 0) onSubmit(b);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="min-h-[calc(100vh-64px)] bg-[#f7f9fc] flex flex-col items-center justify-center px-4 py-16"
    >
      <div className="w-full max-w-xl">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-blue-100 mb-4">
            <DollarSign className="w-7 h-7 text-[#0c3b8f]" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">
            What's your budget?
          </h1>
          <p className="mt-2 text-gray-500 text-base">
            We'll find the best options within your range
          </p>
          {searchParams?.destination && (
            <p className="mt-1 text-sm text-[#0c3b8f] font-medium">
              📍 {searchParams.destination} · {selectedServices.join(", ")}
            </p>
          )}
        </div>

        {/* Preset Buttons */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {BUDGET_PRESETS.map((amount) => (
            <button
              key={amount}
              onClick={() => handlePreset(amount)}
              className={`py-3 rounded-xl border-2 text-sm font-semibold transition-all duration-200
                ${budget === String(amount) && !custom
                  ? "border-[#0c3b8f] bg-blue-50 text-[#0c3b8f]"
                  : "border-gray-200 bg-white text-gray-700 hover:border-[#0c3b8f]/40"
                }`}
            >
              ${amount.toLocaleString()}
            </button>
          ))}
        </div>

        {/* Custom Input */}
        <div className="mb-8">
          <button
            onClick={() => { setCustom(true); setBudget(""); }}
            className={`text-sm font-medium mb-3 transition-colors ${custom ? "text-[#0c3b8f]" : "text-gray-400 hover:text-gray-600"}`}
          >
            + Enter custom amount
          </button>
          {custom && (
            <div className="flex items-center border-2 border-[#0c3b8f] rounded-xl bg-white px-4 py-3 gap-2">
              <span className="text-gray-500 font-semibold">$</span>
              <input
                type="number"
                autoFocus
                placeholder="e.g. 2500"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="flex-1 outline-none text-base font-semibold text-gray-800 bg-transparent"
              />
            </div>
          )}
        </div>

        <button
          onClick={handleSubmit}
          disabled={!budget || parseFloat(budget) <= 0}
          className="w-full bg-[#0c3b8f] hover:bg-[#072a66] disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-base py-4 rounded-full shadow-lg transition-all duration-200 hover:scale-[1.02]"
        >
          Show Options →
        </button>
      </div>
    </motion.div>
  );
}