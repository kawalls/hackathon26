import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plane, Car, Ship, Hotel, Trees, Home, Map, Search, Star, MapPin, Wifi, Coffee, ParkingCircle, Waves, Dumbbell, Zap, GitCompare, SlidersHorizontal, X } from "lucide-react";
import ItineraryCompareModal from "./ItineraryCompareModal";

const SERVICE_ICONS = {
  flights: Plane, rentals: Car, cruise: Ship,
  hotels: Hotel, resorts: Trees, airbnbs: Home,
};

const SERVICE_OPTIONS = {
  flights: [
    { name: "Economy Escape", location: "Main Terminal • 2.1 mi from city", price: 180, rating: 4.2, reviews: 1240, stars: 3, district: "Economy Class · Round-trip", image: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=600&q=80", amenities: { wifi: true, pool: false, breakfast: true, parking: false, fitness: false, spa: false }, roomTypes: ["Economy", "Basic Economy"] },
    { name: "Business Elite", location: "Terminal B • 1.5 mi from city", price: 650, rating: 4.7, reviews: 890, stars: 5, district: "Business Class · Priority Boarding", image: "https://images.unsplash.com/photo-1474302770737-173ee21bab63?w=600&q=80", amenities: { wifi: true, pool: false, breakfast: true, parking: true, fitness: false, spa: false }, roomTypes: ["Business", "Premium Business"] },
    { name: "First Class Luxury", location: "VIP Terminal • 0.8 mi from city", price: 1400, rating: 4.9, reviews: 562, stars: 5, district: "First Class · Lounge Access", image: "https://images.unsplash.com/photo-1540339832862-474599807836?w=600&q=80", amenities: { wifi: true, pool: false, breakfast: true, parking: true, fitness: true, spa: true }, roomTypes: ["First Class", "Suite Class"] },
  ],
  rentals: [
    { name: "Economy Compact", location: "Airport Pickup • 0.5 mi from center", price: 35, rating: 4.1, reviews: 2340, stars: 3, district: "Compact Car · Great on Gas", image: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=600&q=80", amenities: { wifi: false, pool: false, breakfast: false, parking: true, fitness: false, spa: false }, roomTypes: ["Compact", "Mini"] },
    { name: "Family SUV", location: "Downtown Lot • 1.2 mi from center", price: 75, rating: 4.5, reviews: 1780, stars: 4, district: "SUV · Spacious for Families", image: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=600&q=80", amenities: { wifi: true, pool: false, breakfast: false, parking: true, fitness: false, spa: false }, roomTypes: ["SUV", "Minivan"] },
    { name: "Luxury Convertible", location: "VIP Lot • 0.3 mi from center", price: 150, rating: 4.8, reviews: 430, stars: 5, district: "Luxury · Full Insurance Included", image: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=600&q=80", amenities: { wifi: true, pool: false, breakfast: false, parking: true, fitness: false, spa: false }, roomTypes: ["Luxury", "Sports"] },
  ],
  cruise: [
    { name: "Interior Cabin", location: "Port Miami • 0.2 mi from boardwalk", price: 400, rating: 4.0, reviews: 3200, stars: 3, district: "7-Night Cruise · Interior Stateroom", image: "https://images.unsplash.com/photo-1548574505-5e239809ee19?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: false }, roomTypes: ["Interior", "Standard"] },
    { name: "Ocean View Balcony", location: "Port Everglades • 0.5 mi from terminal", price: 750, rating: 4.6, reviews: 1890, stars: 4, district: "7-Night Cruise · Ocean View", image: "https://images.unsplash.com/photo-1599640842225-85d111c60e6b?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: true }, roomTypes: ["Ocean View", "Balcony"] },
    { name: "Suite Package", location: "PortMiami • 0.1 mi from terminal", price: 2200, rating: 4.9, reviews: 720, stars: 5, district: "7-Night Cruise · Butler Service", image: "https://images.unsplash.com/photo-1610641818989-c2051b5e2cfd?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: true }, roomTypes: ["Suite", "Grand Suite", "Owner's Suite"] },
  ],
  hotels: [
    { name: "Budget Comfort Inn", location: "City Center • 0.8 mi from downtown", price: 60, rating: 3.9, reviews: 4200, stars: 3, district: "City Center · Great Location", image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&q=80", amenities: { wifi: true, pool: false, breakfast: false, parking: true, fitness: false, spa: false }, roomTypes: ["Standard", "Double"] },
    { name: "Midtown Plaza Hotel", location: "Midtown District • 0.4 mi from center", price: 120, rating: 4.4, reviews: 2870, stars: 4, district: "Midtown · Pool & Gym Included", image: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: false }, roomTypes: ["Deluxe", "Suite", "Family Room"] },
    { name: "Grand Luxury Resort", location: "Beachfront • 0.1 mi from beach", price: 350, rating: 4.9, reviews: 1540, stars: 5, district: "Beachfront · Fine Dining & Spa", image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: true }, roomTypes: ["Ocean Suite", "Penthouse", "Royal Suite"] },
  ],
  resorts: [
    { name: "All-Inclusive Basics", location: "Resort Row • 1.0 mi from beach", price: 200, rating: 4.2, reviews: 3100, stars: 4, district: "All-Inclusive · Meals & Drinks", image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: false }, roomTypes: ["Standard", "Garden View"] },
    { name: "Premium Beach Resort", location: "Beachfront • 0.2 mi from water", price: 400, rating: 4.7, reviews: 1650, stars: 5, district: "All-Inclusive Plus · Spa Access", image: "https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: true }, roomTypes: ["Deluxe", "Ocean View", "Suite"] },
    { name: "Ultra Luxury Villa", location: "Private Island • 2.0 mi offshore", price: 900, rating: 5.0, reviews: 320, stars: 5, district: "Private Beach · Butler Service", image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: true, parking: true, fitness: true, spa: true }, roomTypes: ["Villa", "Private Villa", "Overwater Bungalow"] },
  ],
  airbnbs: [
    { name: "Cozy City Room", location: "Downtown • 0.6 mi from center", price: 50, rating: 4.3, reviews: 890, stars: 3, district: "Private Room · Shared Home", image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=600&q=80", amenities: { wifi: true, pool: false, breakfast: false, parking: false, fitness: false, spa: false }, roomTypes: ["Private Room"] },
    { name: "Modern Apartment", location: "Arts District • 1.1 mi from center", price: 110, rating: 4.6, reviews: 1240, stars: 4, district: "Entire Apartment · Self Check-in", image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600&q=80", amenities: { wifi: true, pool: false, breakfast: false, parking: true, fitness: false, spa: false }, roomTypes: ["Studio", "1-Bedroom", "2-Bedroom"] },
    { name: "Luxury Pool Villa", location: "Hillside Estate • 3.0 mi from center", price: 500, rating: 4.9, reviews: 280, stars: 5, district: "Entire Villa · Private Pool & Views", image: "https://images.unsplash.com/photo-1613977257365-aaae5a9817ff?w=600&q=80", amenities: { wifi: true, pool: true, breakfast: false, parking: true, fitness: true, spa: false }, roomTypes: ["Villa", "Guest House"] },
  ],
};

const AMENITY_ICONS = [
  { key: "wifi", icon: Wifi },
  { key: "pool", icon: Waves },
  { key: "breakfast", icon: Coffee },
  { key: "parking", icon: ParkingCircle },
  { key: "fitness", icon: Dumbbell },
  { key: "spa", icon: Zap },
];

function OptionCard({ item, isCompared, onToggleCompare, compareDisabled }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border-2 flex flex-col ${isCompared ? "border-[#0c3b8f]" : "border-gray-100"}`}
    >
      <div className="relative h-44 overflow-hidden shrink-0">
        <img src={item.image} alt={item.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
        <div className="absolute top-3 right-3 bg-[#0c3b8f] text-white text-sm font-bold px-3 py-1 rounded-lg shadow">
          ${item.price}/night
        </div>
      </div>

      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-bold text-base text-gray-900 leading-tight">{item.name}</h3>
        <div className="flex items-start gap-1 mt-1">
          <MapPin className="w-3.5 h-3.5 text-gray-400 mt-0.5 shrink-0" />
          <span className="text-xs text-gray-500">{item.district}</span>
        </div>

        <div className="flex items-center gap-2 mt-2.5">
          <div className="flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className={`w-3.5 h-3.5 ${i < Math.round(item.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-200 fill-gray-200"}`} />
            ))}
          </div>
          <span className="text-xs font-semibold text-gray-700">{item.rating}</span>
          <span className="text-xs text-gray-400">({item.reviews.toLocaleString()} reviews)</span>
        </div>

        <div className="flex items-center gap-3 mt-3 pt-3 border-t border-gray-100">
          {AMENITY_ICONS.map(({ key, icon: Icon }) => (
            <Icon key={key} className={`w-4 h-4 ${item.amenities?.[key] ? "text-gray-500" : "text-gray-200"}`} />
          ))}
        </div>

        <p className="text-xs text-gray-500 mt-2.5">{item.roomTypes?.length} room types available</p>

        <div className="flex items-center gap-2 mt-3">
          <button className="flex-1 bg-[#0c3b8f] hover:bg-[#072a66] text-white text-sm font-bold py-2.5 rounded-lg transition-all duration-200">
            View Details
          </button>
          <button
            onClick={() => onToggleCompare?.(item)}
            disabled={compareDisabled}
            className={`p-2.5 rounded-lg border transition-all duration-200 ${
              isCompared ? "bg-[#0c3b8f]/10 border-[#0c3b8f] text-[#0c3b8f]"
              : compareDisabled ? "border-gray-200 text-gray-300 cursor-not-allowed"
              : "border-gray-200 text-gray-500 hover:border-[#0c3b8f] hover:text-[#0c3b8f]"
            }`}
          >
            <GitCompare className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export default function ItineraryResults({ selectedServices, budget, searchParams, onReset }) {
  const [maxPrice, setMaxPrice] = useState(budget || 500);
  const [starsFilter, setStarsFilter] = useState([]);
  const [amenityFilters, setAmenityFilters] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("recommended");
  const [compareList, setCompareList] = useState([]);
  const [showCompareModal, setShowCompareModal] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleStar = (s) => setStarsFilter(p => p.includes(s) ? p.filter(x => x !== s) : [...p, s]);
  const toggleAmenity = (a) => setAmenityFilters(p => p.includes(a) ? p.filter(x => x !== a) : [...p, a]);
  const toggleCompare = (item) => setCompareList(p => {
    if (p.find(x => x._compareId === item._compareId)) return p.filter(x => x._compareId !== item._compareId);
    if (p.length >= 3) return p;
    return [...p, item];
  });

  // Collect all items from selected services
  const allItems = selectedServices.flatMap(svc =>
    (SERVICE_OPTIONS[svc] || []).map((opt, i) => ({ ...opt, _service: svc, _compareId: `${svc}-${i}` }))
  );

  const filtered = allItems
    .filter(item => {
      if (item.price > maxPrice) return false;
      if (starsFilter.length > 0 && !starsFilter.includes(item.stars)) return false;
      if (amenityFilters.length > 0 && !amenityFilters.every(a => item.amenities?.[a])) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (!item.name.toLowerCase().includes(q) && !item.location.toLowerCase().includes(q)) return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "price_asc") return a.price - b.price;
      if (sortBy === "price_desc") return b.price - a.price;
      if (sortBy === "rating") return b.rating - a.rating;
      return 0;
    });

  return (
    <div className="bg-[#f7f9fc] min-h-screen pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Your Options</h2>
          <span className="text-sm text-gray-500">{filtered.length} options available</span>
        </div>
      </div>

      {/* Search + Sort */}
      <div className="bg-white border-b border-gray-200 px-4 sm:px-8 py-3 sticky top-16 z-20">
        <div className="max-w-7xl mx-auto flex items-center gap-3">
          <div className="flex-1 flex items-center gap-2 border border-gray-200 rounded-lg px-3 py-2 bg-white">
            <Search className="w-4 h-4 text-gray-400 shrink-0" />
            <input
              type="text"
              placeholder="Search by name or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 text-sm outline-none bg-transparent text-gray-700 placeholder-gray-400"
            />
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white focus:outline-none shrink-0"
          >
            <option value="recommended">Sort: Recommended</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="flex items-center gap-1.5 sm:hidden text-sm font-semibold text-[#0c3b8f] border border-[#0c3b8f] rounded-lg px-3 py-2"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 flex gap-6">
        {/* Sidebar */}
        <div className="shrink-0 w-56 hidden sm:block">
          <aside className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-6 sticky top-28">
            <h3 className="text-base font-bold text-gray-900">Filters</h3>

            <div>
              <p className="text-sm font-semibold text-gray-800 mb-3">Price per Night</p>
              <input type="range" min={0} max={budget || 2500} step={10} value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[#0c3b8f] cursor-pointer" />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>$0</span>
                <span className="font-semibold text-[#0c3b8f]">${maxPrice}</span>
                <span>${budget || 2500}</span>
              </div>
            </div>

            <div className="border-t border-gray-100" />

            <div>
              <p className="text-sm font-semibold text-gray-800 mb-3">Star Rating</p>
              <div className="space-y-2.5">
                {[5, 4, 3].map(s => (
                  <label key={s} className="flex items-center gap-2.5 cursor-pointer group">
                    <input type="checkbox" checked={starsFilter.includes(s)} onChange={() => toggleStar(s)} className="accent-[#0c3b8f] w-4 h-4 rounded" />
                    <span className="flex gap-0.5">
                      {Array.from({ length: s }).map((_, i) => <Star key={i} className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />)}
                    </span>
                    <span className="text-sm text-gray-600">& up</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="border-t border-gray-100" />

            <div>
              <p className="text-sm font-semibold text-gray-800 mb-3">Amenities</p>
              <div className="space-y-2.5">
                {[
                  { id: "wifi", label: "Free WiFi", icon: Wifi },
                  { id: "breakfast", label: "Breakfast", icon: Coffee },
                  { id: "parking", label: "Parking", icon: ParkingCircle },
                  { id: "fitness", label: "Fitness Center", icon: Dumbbell },
                  { id: "pool", label: "Swimming Pool", icon: Waves },
                  { id: "spa", label: "Spa", icon: Zap },
                ].map(({ id, label, icon: Icon }) => (
                  <label key={id} className="flex items-center gap-2.5 cursor-pointer group">
                    <input type="checkbox" checked={amenityFilters.includes(id)} onChange={() => toggleAmenity(id)} className="accent-[#0c3b8f] w-4 h-4 rounded" />
                    <Icon className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span className={`text-sm ${amenityFilters.includes(id) ? "text-[#0c3b8f] font-semibold" : "text-gray-600"}`}>{label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="border-t border-gray-100" />

            <div>
              <p className="text-sm font-semibold text-gray-800 mb-3">Distance from Center</p>
              <input type="range" min={1} max={20} defaultValue={10} className="w-full accent-[#0c3b8f] cursor-pointer" />
              <p className="text-xs text-gray-500 mt-1">Within 10 miles</p>
            </div>
          </aside>
        </div>

        {/* Mobile Sidebar */}
        <AnimatePresence>
          {sidebarOpen && (
            <motion.div initial={{ x: -300, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -300, opacity: 0 }} className="fixed inset-0 z-40 sm:hidden">
              <div className="absolute inset-0 bg-black/40" onClick={() => setSidebarOpen(false)} />
              <div className="absolute left-0 top-0 bottom-0 w-72 bg-white overflow-y-auto p-4">
                <p className="font-bold mb-4">Filters</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Grid */}
        <div className="flex-1 min-w-0">
          {filtered.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              <AnimatePresence>
                {filtered.map((item, i) => (
                  <OptionCard
                    key={`${item._service}-${i}`}
                    item={item}
                    isCompared={!!compareList.find(x => x._compareId === item._compareId)}
                    onToggleCompare={toggleCompare}
                    compareDisabled={compareList.length >= 3 && !compareList.find(x => x._compareId === item._compareId)}
                  />
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="text-center py-20">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-500">No options match your filters</p>
              <p className="text-sm text-gray-400 mt-1">Try adjusting your budget or filters</p>
            </div>
          )}
        </div>
      </div>

      <div className="text-center mt-4 pb-6">
        <button onClick={onReset} className="text-sm text-gray-400 hover:text-[#0c3b8f] font-medium transition-colors">
          ← Start over
        </button>
      </div>

      {/* Compare Bar */}
      <AnimatePresence>
        {compareList.length >= 1 && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-gray-200 shadow-2xl px-4 sm:px-8 py-3"
          >
            <div className="max-w-7xl mx-auto flex items-center gap-4">
              <div className="flex items-center gap-3 flex-1 overflow-x-auto">
                <span className="text-sm font-bold text-gray-700 shrink-0">Compare:</span>
                {compareList.map((item) => (
                  <div key={item._compareId} className="flex items-center gap-2 bg-gray-100 rounded-lg px-3 py-1.5 shrink-0">
                    <img src={item.image} alt={item.name} className="w-8 h-8 rounded object-cover" />
                    <span className="text-xs font-semibold text-gray-700 max-w-[100px] truncate">{item.name}</span>
                    <button onClick={() => toggleCompare(item)} className="text-gray-400 hover:text-red-500 transition-colors">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                {compareList.length < 3 && (
                  <div className="flex items-center gap-2 border-2 border-dashed border-gray-300 rounded-lg px-3 py-1.5 shrink-0">
                    <span className="text-xs text-gray-400">+ Add option</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button onClick={() => setCompareList([])} className="text-sm text-gray-500 hover:text-gray-700 font-medium px-3 py-2">
                  Clear
                </button>
                <button
                  onClick={() => setShowCompareModal(true)}
                  disabled={compareList.length < 2}
                  className="bg-[#0c3b8f] hover:bg-[#072a66] disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-bold px-5 py-2 rounded-lg transition-all"
                >
                  Compare Now ({compareList.length})
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Compare Modal */}
      <AnimatePresence>
        {showCompareModal && (
          <ItineraryCompareModal
            items={compareList}
            onClose={() => setShowCompareModal(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}