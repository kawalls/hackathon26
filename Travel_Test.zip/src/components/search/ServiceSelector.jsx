import React from "react";
import { Plane, Car, Ship, Home, Hotel, Trees } from "lucide-react";
import { motion } from "framer-motion";

const SERVICES = [
  { id: "flights", label: "Flights", icon: Plane },
  { id: "rentals", label: "Rentals", icon: Car },
  { id: "cruise", label: "Cruise", icon: Ship },
  { id: "hotels", label: "Hotels", icon: Hotel },
  { id: "resorts", label: "Resorts", icon: Trees },
  { id: "airbnbs", label: "Airbnbs", icon: Home },
];

export default function ServiceSelector({ selected, onToggle, onNext, searchParams }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="min-h-[calc(100vh-64px)] bg-[#f7f9fc] flex flex-col items-center justify-center px-4 py-16"
    >
      <div className="w-full max-w-3xl">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">
            Vacation Information
          </h1>
          <p className="mt-2 text-gray-500 text-base">
            Choose your travel service
          </p>
          {searchParams?.destination && (
            <p className="mt-1 text-sm text-[#0c3b8f] font-medium">
              📍 {searchParams.destination}
            </p>
          )}
        </div>

        {/* Service Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-10">
          {SERVICES.map((service, i) => {
            const Icon = service.icon;
            const isSelected = selected.includes(service.id);
            return (
              <motion.button
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06, duration: 0.3 }}
                onClick={() => onToggle(service.id)}
                className={`flex flex-col items-center justify-center gap-4 p-8 rounded-2xl border-2 transition-all duration-200 cursor-pointer bg-white shadow-sm hover:shadow-md
                  ${isSelected
                    ? "border-[#0c3b8f] bg-blue-50 shadow-md"
                    : "border-gray-100 hover:border-[#0c3b8f]/30"
                  }`}
              >
                <Icon
                  className={`w-12 h-12 ${isSelected ? "text-[#0c3b8f]" : "text-[#2563eb]"}`}
                  strokeWidth={1.5}
                />
                <span className={`text-base font-semibold ${isSelected ? "text-[#0c3b8f]" : "text-gray-800"}`}>
                  {service.label}
                </span>
                {isSelected && (
                  <span className="absolute top-3 right-3 w-5 h-5 bg-[#0c3b8f] rounded-full flex items-center justify-center text-white text-xs">✓</span>
                )}
              </motion.button>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-400">
            {selected.length === 0
              ? "Select at least one service"
              : `${selected.length} service${selected.length > 1 ? "s" : ""} selected`}
          </p>
          <button
            onClick={onNext}
            disabled={selected.length === 0}
            className="flex items-center gap-2 bg-[#0c3b8f] hover:bg-[#072a66] disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-sm px-8 py-3 rounded-full shadow-lg transition-all duration-200 hover:scale-[1.02]"
          >
            Next →
          </button>
        </div>
      </div>
    </motion.div>
  );
}