import React from "react";
import { Plane } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const footerLinks = {
  Company: ["About us", "Jobs", "List your property", "Partnerships", "Newsroom"],
  Explore: ["Hotels", "Flights", "Car rentals", "Vacation packages", "Travel guides"],
  Policies: ["Privacy", "Terms of Use", "Accessibility", "Rate accuracy promise"],
  Help: ["Support", "Cancel your booking", "Use a coupon", "Refund policies", "Contact us"],
};

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-8">
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-bold text-sm text-gray-900 mb-4">{title}</h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-xs text-gray-500 hover:text-[#0c3b8f] transition-colors duration-200">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Newsletter */}
          <div className="col-span-2">
            <h4 className="font-bold text-sm text-gray-900 mb-2">Travel deals</h4>
            <p className="text-xs text-gray-500 mb-4 leading-relaxed">
              Get exclusive offers and travel inspiration delivered to your inbox
            </p>
            <div className="flex gap-2">
              <Input
                placeholder="Email address"
                className="h-10 rounded-xl text-sm border-gray-200 flex-1"
              />
              <Button className="h-10 bg-[#0c3b8f] hover:bg-[#072a66] text-white text-xs font-semibold rounded-xl px-5 shrink-0">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Plane className="w-4 h-4 text-[#0c3b8f]" />
            <span className="text-sm font-bold text-[#0c3b8f]">TravelHub</span>
          </div>
          <p className="text-xs text-gray-400">© 2026 TravelHub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}