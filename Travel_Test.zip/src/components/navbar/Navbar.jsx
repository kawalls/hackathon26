import React, { useState } from "react";
import { Menu, X, Plane, Car, Package, Tag, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import SidebarMenu from "./SidebarMenu";

const navLinks = [
  { label: "Stays", icon: Building2 },
  { label: "Flights", icon: Plane },
  { label: "Cars", icon: Car },
  { label: "Packages", icon: Package },
  { label: "Deals", icon: Tag },
];

export default function Navbar() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0c3b8f]/80 backdrop-blur-md text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left: Logo + Hamburger */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-lg hover:bg-white/10 transition-colors"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <Plane className="w-6 h-6 text-white" />
                <span className="text-xl font-bold tracking-tight">TravelHub</span>
              </div>
            </div>

            {/* Center: Nav Links (desktop) */}
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white/90 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
                >
                  <link.icon className="w-4 h-4" />
                  {link.label}
                </button>
              ))}
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-3">
              <button className="hidden sm:block text-sm font-medium text-white/90 hover:text-white transition-colors">
                List your property
              </button>
              <button className="hidden sm:block text-sm font-medium text-white/90 hover:text-white transition-colors">
                Support
              </button>
              <Button className="bg-[#f5a623] hover:bg-[#e09610] text-white font-semibold px-5 py-2 rounded-full text-sm shadow-lg shadow-yellow-500/20 transition-all duration-200">
                Sign in
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <SidebarMenu isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
    </>
  );
}