import React, { useEffect } from "react";
import { X, Home, Search, Briefcase, Heart, User, HelpCircle, Plane } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const menuItems = [
  { label: "Home", icon: Home },
  { label: "Search Hotels", icon: Search },
  { label: "Trips", icon: Briefcase },
  { label: "Favorites", icon: Heart },
  { label: "Account", icon: User },
  { label: "Support", icon: HelpCircle },
];

export default function SidebarMenu({ isOpen, onClose }) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
            onClick={onClose}
          />

          {/* Sidebar */}
          <motion.aside
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className="fixed top-0 left-0 bottom-0 w-[300px] max-w-[85vw] bg-white z-[70] shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <Plane className="w-5 h-5 text-[#0c3b8f]" />
                <span className="text-lg font-bold text-[#0c3b8f] tracking-tight">TravelHub</span>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Menu Items */}
            <nav className="flex-1 py-4 px-3">
              {menuItems.map((item, index) => (
                <motion.button
                  key={item.label}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05, duration: 0.3 }}
                  className="w-full flex items-center gap-3.5 px-4 py-3.5 text-gray-700 hover:bg-[#0c3b8f]/5 hover:text-[#0c3b8f] rounded-xl transition-all duration-200 group"
                >
                  <item.icon className="w-5 h-5 text-gray-400 group-hover:text-[#0c3b8f] transition-colors" />
                  <span className="font-medium text-sm">{item.label}</span>
                </motion.button>
              ))}
            </nav>

            {/* Footer */}
            <div className="px-6 py-5 border-t border-gray-100">
              <p className="text-xs text-gray-400">© 2026 TravelHub. All rights reserved.</p>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}