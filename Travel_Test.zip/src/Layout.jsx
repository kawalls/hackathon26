import React from "react";
import Navbar from "@/components/navbar/Navbar";

export default function Layout({ children, currentPageName }) {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main className="pt-16">
        {children}
      </main>
    </div>
  );
}