import { Link } from "react-router";
import { Plane, Building2, Car, Package, Gift, Menu } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-[#003b95] text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <Plane className="h-8 w-8" />
            <span className="text-2xl font-bold">TravelHub</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Link to="/hotels" className="flex items-center gap-2 hover:text-yellow-300 transition">
              <Building2 className="h-4 w-4" />
              <span>Stays</span>
            </Link>
            <Link to="/flights" className="flex items-center gap-2 hover:text-yellow-300 transition">
              <Plane className="h-4 w-4" />
              <span>Flights</span>
            </Link>
            <Link to="/deals" className="flex items-center gap-2 hover:text-yellow-300 transition">
              <Car className="h-4 w-4" />
              <span>Cars</span>
            </Link>
            <Link to="/deals" className="flex items-center gap-2 hover:text-yellow-300 transition">
              <Package className="h-4 w-4" />
              <span>Packages</span>
            </Link>
            <Link to="/deals" className="flex items-center gap-2 hover:text-yellow-300 transition">
              <Gift className="h-4 w-4" />
              <span>Deals</span>
            </Link>
          </nav>

          {/* User Actions */}
          <div className="hidden md:flex items-center gap-3">
            <Button variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10">
              List your property
            </Button>
            <Button variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10">
              Support
            </Button>
            <Button className="bg-yellow-400 text-[#003b95] hover:bg-yellow-500">
              Sign in
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 hover:bg-white/10 rounded-lg transition"
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-white/20">
            <nav className="flex flex-col gap-3">
              <Link to="/hotels" className="flex items-center gap-2 py-2 hover:text-yellow-300">
                <Building2 className="h-4 w-4" />
                <span>Stays</span>
              </Link>
              <Link to="/flights" className="flex items-center gap-2 py-2 hover:text-yellow-300">
                <Plane className="h-4 w-4" />
                <span>Flights</span>
              </Link>
              <Link to="/deals" className="flex items-center gap-2 py-2 hover:text-yellow-300">
                <Car className="h-4 w-4" />
                <span>Cars</span>
              </Link>
              <Link to="/deals" className="flex items-center gap-2 py-2 hover:text-yellow-300">
                <Package className="h-4 w-4" />
                <span>Packages</span>
              </Link>
              <Link to="/deals" className="flex items-center gap-2 py-2 hover:text-yellow-300">
                <Gift className="h-4 w-4" />
                <span>Deals</span>
              </Link>
              <div className="flex flex-col gap-2 mt-3 pt-3 border-t border-white/20">
                <Button variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10 justify-start">
                  List your property
                </Button>
                <Button variant="ghost" className="text-white hover:text-yellow-300 hover:bg-white/10 justify-start">
                  Support
                </Button>
                <Button className="bg-yellow-400 text-[#003b95] hover:bg-yellow-500">
                  Sign in
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
