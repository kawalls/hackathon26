import { Star, MapPin, Calendar, Users, Percent } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

const deals = [
  {
    id: 1,
    type: "hotel",
    title: "Luxury Beach Resort Package",
    location: "Maldives",
    image: "https://images.unsplash.com/photo-1678687114989-ad452a24f289?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFjaCUyMHJlc29ydCUyMHZhY2F0aW9ufGVufDF8fHx8MTc3Mjg2NzI3OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 299,
    originalPrice: 599,
    discount: 50,
    rating: 4.8,
    reviews: 1245,
    duration: "5 nights",
    description: "All-inclusive resort with private beach access",
  },
  {
    id: 2,
    type: "package",
    title: "Northern Lights Adventure",
    location: "Iceland",
    image: "https://images.unsplash.com/photo-1488415032361-b7e238421f1b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpY2VsYW5kJTIwbm9ydGhlcm4lMjBsaWdodHN8ZW58MXx8fHwxNzcyNzQ1NTU2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 189,
    originalPrice: 349,
    discount: 46,
    rating: 4.9,
    reviews: 892,
    duration: "4 nights",
    description: "Flight + Hotel + Northern Lights tour included",
  },
  {
    id: 3,
    type: "hotel",
    title: "5-Star City Center Hotel",
    location: "New York",
    image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb218ZW58MXx8fHwxNzcyNzY4ODE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 219,
    originalPrice: 459,
    discount: 52,
    rating: 4.7,
    reviews: 2134,
    duration: "3 nights",
    description: "Premium location near Times Square",
  },
  {
    id: 4,
    type: "package",
    title: "Paris Romance Package",
    location: "Paris, France",
    image: "https://images.unsplash.com/photo-1431274172761-fca41d930114?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyfGVufDF8fHx8MTc3Mjc1OTc0M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 349,
    originalPrice: 699,
    discount: 50,
    rating: 4.9,
    reviews: 1823,
    duration: "5 nights",
    description: "Flight + Hotel + Seine River cruise",
  },
  {
    id: 5,
    type: "hotel",
    title: "Tropical Island Retreat",
    location: "Bali, Indonesia",
    image: "https://images.unsplash.com/photo-1599117372066-46efdebe2c42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxpJTIwdGVtcGxlJTIwaXNsYW5kfGVufDF8fHx8MTc3Mjg2NzI4MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 169,
    originalPrice: 329,
    discount: 49,
    rating: 4.8,
    reviews: 1456,
    duration: "6 nights",
    description: "Beach villa with private pool",
  },
  {
    id: 6,
    type: "package",
    title: "Dubai Luxury Experience",
    location: "Dubai, UAE",
    image: "https://images.unsplash.com/photo-1682879654288-3bc35430b79f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMGRlc2VydCUyMGx1eHVyeXxlbnwxfHx8fDE3NzI4MzUyODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 449,
    originalPrice: 899,
    discount: 50,
    rating: 4.8,
    reviews: 2104,
    duration: "4 nights",
    description: "Flight + 5-star hotel + Desert safari",
  },
];

export function Deals() {
  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <Percent className="h-8 w-8 text-[#003b95]" />
            <h1 className="text-3xl">Hot Deals & Special Offers</h1>
          </div>
          <p className="text-gray-600">
            Save big on your next trip with our exclusive deals
          </p>
        </div>

        {/* Featured Banner */}
        <Card className="mb-8 overflow-hidden bg-gradient-to-r from-[#003b95] to-[#0051c7] text-white">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <Badge className="bg-yellow-400 text-[#003b95] mb-3">
                  Limited Time Offer
                </Badge>
                <h2 className="text-3xl mb-2">Up to 50% off on select hotels</h2>
                <p className="text-blue-100 mb-4">
                  Book by March 31st for travel through December 2026
                </p>
                <Button className="bg-white text-[#003b95] hover:bg-gray-100">
                  Browse all deals
                </Button>
              </div>
              <div className="text-center">
                <div className="text-6xl mb-2">50%</div>
                <div className="text-xl">OFF</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="all" className="mb-8">
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Deals</TabsTrigger>
            <TabsTrigger value="hotels">Hotels</TabsTrigger>
            <TabsTrigger value="packages">Packages</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {deals.map((deal) => (
                <DealCard key={deal.id} deal={deal} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="hotels">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {deals
                .filter((deal) => deal.type === "hotel")
                .map((deal) => (
                  <DealCard key={deal.id} deal={deal} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="packages">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {deals
                .filter((deal) => deal.type === "package")
                .map((deal) => (
                  <DealCard key={deal.id} deal={deal} />
                ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Newsletter */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl mb-3">Never miss a deal</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Sign up for our newsletter and be the first to know about exclusive
              deals and travel inspiration
            </p>
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003b95]"
              />
              <Button className="bg-[#003b95] hover:bg-[#002e75]">
                Subscribe
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function DealCard({ deal }: { deal: typeof deals[0] }) {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow">
      <div className="relative h-48">
        <ImageWithFallback
          src={deal.image}
          alt={deal.title}
          className="w-full h-full object-cover"
        />
        <Badge className="absolute top-4 right-4 bg-red-500 hover:bg-red-600 text-lg px-3 py-1">
          {deal.discount}% OFF
        </Badge>
        {deal.type === "package" && (
          <Badge className="absolute top-4 left-4 bg-[#003b95] hover:bg-[#002e75]">
            Package Deal
          </Badge>
        )}
      </div>
      <CardContent className="p-5">
        <h3 className="text-xl mb-2">{deal.title}</h3>
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
          <MapPin className="h-4 w-4" />
          <span>{deal.location}</span>
        </div>

        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            <span>{deal.rating}</span>
          </div>
          <span className="text-sm text-gray-500">
            ({deal.reviews.toLocaleString()} reviews)
          </span>
        </div>

        <p className="text-sm text-gray-600 mb-4">{deal.description}</p>

        <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
          <Calendar className="h-4 w-4" />
          <span>{deal.duration}</span>
        </div>

        <div className="flex items-center justify-between pt-4 border-t">
          <div>
            <div className="text-sm text-gray-500 line-through mb-1">
              ${deal.originalPrice}
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl text-[#003b95]">${deal.price}</span>
              <span className="text-sm text-gray-600">per person</span>
            </div>
          </div>
          <Button className="bg-[#003b95] hover:bg-[#002e75]">Book now</Button>
        </div>
      </CardContent>
    </Card>
  );
}
