import { useState } from "react";
import { Star, MapPin, Wifi, Car, UtensilsCrossed, Dumbbell, Check } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Slider } from "./ui/slider";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";

const hotels = [
  {
    id: 1,
    name: "Grand Ocean Resort & Spa",
    location: "Miami Beach, Florida",
    image: "https://images.unsplash.com/photo-1678687114989-ad452a24f289?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFjaCUyMHJlc29ydCUyMHZhY2F0aW9ufGVufDF8fHx8MTc3Mjg2NzI3OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 299,
    rating: 4.8,
    reviews: 1245,
    amenities: ["Free WiFi", "Pool", "Restaurant", "Gym", "Parking"],
  },
  {
    id: 2,
    name: "Metropolitan Luxury Suites",
    location: "Manhattan, New York",
    image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb218ZW58MXx8fHwxNzcyNzY4ODE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 419,
    rating: 4.9,
    reviews: 2341,
    amenities: ["Free WiFi", "Restaurant", "Gym", "Parking", "Bar"],
  },
  {
    id: 3,
    name: "Paradise Beach Hotel",
    location: "Bali, Indonesia",
    image: "https://images.unsplash.com/photo-1599117372066-46efdebe2c42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxpJTIwdGVtcGxlJTIwaXNsYW5kfGVufDF8fHx8MTc3Mjg2NzI4MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 189,
    rating: 4.7,
    reviews: 892,
    amenities: ["Free WiFi", "Pool", "Restaurant", "Spa"],
  },
  {
    id: 4,
    name: "Downtown Business Hotel",
    location: "Tokyo, Japan",
    image: "https://images.unsplash.com/photo-1583915223588-7d88ebf23414?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b2t5byUyMGNpdHklMjBuaWdodHxlbnwxfHx8fDE3NzI3OTc2Mzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 259,
    rating: 4.6,
    reviews: 1567,
    amenities: ["Free WiFi", "Restaurant", "Gym", "Bar"],
  },
  {
    id: 5,
    name: "Historic Boutique Hotel",
    location: "Paris, France",
    image: "https://images.unsplash.com/photo-1431274172761-fca41d930114?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyfGVufDF8fHx8MTc3Mjc1OTc0M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 379,
    rating: 4.9,
    reviews: 1823,
    amenities: ["Free WiFi", "Restaurant", "Bar", "Concierge"],
  },
  {
    id: 6,
    name: "Luxury Desert Resort",
    location: "Dubai, UAE",
    image: "https://images.unsplash.com/photo-1682879654288-3bc35430b79f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMGRlc2VydCUyMGx1eHVyeXxlbnwxfHx8fDE3NzI4MzUyODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: 549,
    rating: 4.8,
    reviews: 2104,
    amenities: ["Free WiFi", "Pool", "Restaurant", "Gym", "Spa", "Parking"],
  },
];

export function Hotels() {
  const [priceRange, setPriceRange] = useState([0, 600]);

  const amenityIcons: { [key: string]: JSX.Element } = {
    "Free WiFi": <Wifi className="h-4 w-4" />,
    "Parking": <Car className="h-4 w-4" />,
    "Restaurant": <UtensilsCrossed className="h-4 w-4" />,
    "Gym": <Dumbbell className="h-4 w-4" />,
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">Hotels in Popular Destinations</h1>
          <p className="text-gray-600">Showing {hotels.length} properties</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          <aside className="lg:col-span-1">
            <Card className="sticky top-20">
              <CardContent className="p-6">
                <h3 className="text-lg mb-4">Filter by</h3>

                {/* Price Range */}
                <div className="mb-6">
                  <Label className="mb-3 block">Price per night</Label>
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    max={600}
                    step={10}
                    className="mb-2"
                  />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}+</span>
                  </div>
                </div>

                {/* Star Rating */}
                <div className="mb-6">
                  <Label className="mb-3 block">Star rating</Label>
                  <div className="space-y-2">
                    {[5, 4, 3].map((stars) => (
                      <div key={stars} className="flex items-center gap-2">
                        <Checkbox id={`star-${stars}`} />
                        <label htmlFor={`star-${stars}`} className="flex items-center gap-1 cursor-pointer">
                          {Array.from({ length: stars }).map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          ))}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Amenities */}
                <div className="mb-6">
                  <Label className="mb-3 block">Amenities</Label>
                  <div className="space-y-2">
                    {["Free WiFi", "Pool", "Parking", "Restaurant", "Gym"].map((amenity) => (
                      <div key={amenity} className="flex items-center gap-2">
                        <Checkbox id={amenity} />
                        <label htmlFor={amenity} className="text-sm cursor-pointer">
                          {amenity}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Guest Rating */}
                <div>
                  <Label className="mb-3 block">Guest rating</Label>
                  <div className="space-y-2">
                    {["Excellent 4.5+", "Very good 4.0+", "Good 3.5+"].map((rating) => (
                      <div key={rating} className="flex items-center gap-2">
                        <Checkbox id={rating} />
                        <label htmlFor={rating} className="text-sm cursor-pointer">
                          {rating}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </aside>

          {/* Hotels List */}
          <div className="lg:col-span-3 space-y-4">
            {hotels.map((hotel) => (
              <Card key={hotel.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="grid grid-cols-1 md:grid-cols-3">
                  {/* Hotel Image */}
                  <div className="relative h-64 md:h-auto">
                    <ImageWithFallback
                      src={hotel.image}
                      alt={hotel.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Hotel Details */}
                  <CardContent className="md:col-span-2 p-6">
                    <div className="flex flex-col h-full">
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="text-xl mb-1">{hotel.name}</h3>
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <MapPin className="h-4 w-4" />
                              <span>{hotel.location}</span>
                            </div>
                          </div>
                          <Badge className="bg-[#003b95] hover:bg-[#002e75]">
                            <Star className="h-3 w-3 fill-white mr-1" />
                            {hotel.rating}
                          </Badge>
                        </div>

                        <div className="text-sm text-gray-600 mb-3">
                          {hotel.reviews.toLocaleString()} reviews
                        </div>

                        {/* Amenities */}
                        <div className="flex flex-wrap gap-2 mb-4">
                          {hotel.amenities.map((amenity) => (
                            <div
                              key={amenity}
                              className="flex items-center gap-1 text-xs bg-gray-100 px-2 py-1 rounded"
                            >
                              {amenityIcons[amenity] || <Check className="h-3 w-3" />}
                              <span>{amenity}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Price and CTA */}
                      <div className="flex items-end justify-between border-t pt-4 mt-4">
                        <div>
                          <div className="text-sm text-gray-600 mb-1">Starting from</div>
                          <div className="flex items-baseline gap-2">
                            <span className="text-3xl text-[#003b95]">
                              ${hotel.price}
                            </span>
                            <span className="text-sm text-gray-600">per night</span>
                          </div>
                        </div>
                        <Button className="bg-[#003b95] hover:bg-[#002e75]">
                          View details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
