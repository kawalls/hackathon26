import { Plane, Clock, MapPin, ArrowRight } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

const flights = [
  {
    id: 1,
    airline: "SkyWings Airlines",
    departure: {
      time: "08:00 AM",
      airport: "JFK",
      city: "New York",
    },
    arrival: {
      time: "11:30 AM",
      airport: "LAX",
      city: "Los Angeles",
    },
    duration: "5h 30m",
    stops: "Nonstop",
    price: 249,
    seats: 12,
  },
  {
    id: 2,
    airline: "Global Airways",
    departure: {
      time: "02:15 PM",
      airport: "JFK",
      city: "New York",
    },
    arrival: {
      time: "06:00 PM",
      airport: "LAX",
      city: "Los Angeles",
    },
    duration: "5h 45m",
    stops: "Nonstop",
    price: 289,
    seats: 8,
  },
  {
    id: 3,
    airline: "United Express",
    departure: {
      time: "10:30 AM",
      airport: "JFK",
      city: "New York",
    },
    arrival: {
      time: "03:45 PM",
      airport: "LAX",
      city: "Los Angeles",
    },
    duration: "7h 15m",
    stops: "1 stop",
    price: 189,
    seats: 23,
  },
  {
    id: 4,
    airline: "SkyWings Airlines",
    departure: {
      time: "06:00 PM",
      airport: "JFK",
      city: "New York",
    },
    arrival: {
      time: "09:45 PM",
      airport: "LAX",
      city: "Los Angeles",
    },
    duration: "5h 45m",
    stops: "Nonstop",
    price: 319,
    seats: 5,
  },
  {
    id: 5,
    airline: "Pacific Air",
    departure: {
      time: "12:00 PM",
      airport: "JFK",
      city: "New York",
    },
    arrival: {
      time: "04:15 PM",
      airport: "LAX",
      city: "Los Angeles",
    },
    duration: "6h 15m",
    stops: "Nonstop",
    price: 269,
    seats: 15,
  },
];

export function Flights() {
  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl mb-2">New York (JFK) to Los Angeles (LAX)</h1>
          <p className="text-gray-600">
            Saturday, March 15, 2026 • {flights.length} flights available
          </p>
        </div>

        {/* Sorting */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6 flex flex-wrap gap-4">
          <Button variant="outline" className="text-sm">
            Cheapest first
          </Button>
          <Button variant="outline" className="text-sm">
            Fastest first
          </Button>
          <Button variant="outline" className="text-sm">
            Best value
          </Button>
          <Button variant="outline" className="text-sm">
            Morning departures
          </Button>
        </div>

        {/* Flights List */}
        <div className="space-y-4">
          {flights.map((flight) => (
            <Card key={flight.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center gap-6">
                  {/* Flight Info */}
                  <div className="flex-1">
                    {/* Airline */}
                    <div className="flex items-center gap-3 mb-4">
                      <div className="bg-blue-100 rounded-full p-2">
                        <Plane className="h-5 w-5 text-[#003b95]" />
                      </div>
                      <span className="font-medium">{flight.airline}</span>
                    </div>

                    {/* Route */}
                    <div className="grid grid-cols-3 gap-4 items-center">
                      {/* Departure */}
                      <div>
                        <div className="text-2xl mb-1">{flight.departure.time}</div>
                        <div className="text-sm text-gray-600 mb-1">
                          {flight.departure.city}
                        </div>
                        <div className="text-xs text-gray-500">
                          {flight.departure.airport}
                        </div>
                      </div>

                      {/* Duration */}
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-2">
                          <div className="h-px bg-gray-300 flex-1" />
                          <ArrowRight className="h-5 w-5 text-gray-400 mx-2" />
                          <div className="h-px bg-gray-300 flex-1" />
                        </div>
                        <div className="flex items-center justify-center gap-1 text-sm text-gray-600">
                          <Clock className="h-4 w-4" />
                          <span>{flight.duration}</span>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {flight.stops}
                        </div>
                      </div>

                      {/* Arrival */}
                      <div className="text-right">
                        <div className="text-2xl mb-1">{flight.arrival.time}</div>
                        <div className="text-sm text-gray-600 mb-1">
                          {flight.arrival.city}
                        </div>
                        <div className="text-xs text-gray-500">
                          {flight.arrival.airport}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Price and CTA */}
                  <div className="lg:border-l lg:pl-6 flex flex-row lg:flex-col items-center lg:items-end justify-between lg:justify-center gap-3">
                    <div className="text-right">
                      <div className="text-3xl text-[#003b95] mb-1">
                        ${flight.price}
                      </div>
                      <div className="text-sm text-gray-600 mb-2">per person</div>
                      {flight.seats <= 10 && (
                        <Badge variant="destructive" className="text-xs">
                          Only {flight.seats} seats left
                        </Badge>
                      )}
                    </div>
                    <Button className="bg-[#003b95] hover:bg-[#002e75] whitespace-nowrap">
                      Select flight
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Info Box */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="text-lg mb-3">Flight booking tips</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0 text-[#003b95]" />
                <span>Book nonstop flights to save time and reduce hassle</span>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="h-4 w-4 mt-0.5 flex-shrink-0 text-[#003b95]" />
                <span>Morning flights are usually more punctual than evening flights</span>
              </li>
              <li className="flex items-start gap-2">
                <Plane className="h-4 w-4 mt-0.5 flex-shrink-0 text-[#003b95]" />
                <span>Compare prices across different airlines to find the best deal</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
