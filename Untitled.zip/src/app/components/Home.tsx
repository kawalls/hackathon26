import { SearchSection } from "./SearchSection";
import { Star, MapPin, TrendingUp, Percent } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Link } from "react-router";

const popularDestinations = [
  {
    id: 1,
    name: "Paris",
    country: "France",
    image: "https://images.unsplash.com/photo-1431274172761-fca41d930114?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyfGVufDF8fHx8MTc3Mjc1OTc0M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    hotels: "2,451 properties",
  },
  {
    id: 2,
    name: "Tokyo",
    country: "Japan",
    image: "https://images.unsplash.com/photo-1583915223588-7d88ebf23414?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b2t5byUyMGNpdHklMjBuaWdodHxlbnwxfHx8fDE3NzI3OTc2Mzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    hotels: "1,892 properties",
  },
  {
    id: 3,
    name: "New York",
    country: "United States",
    image: "https://images.unsplash.com/photo-1514565131-fce0801e5785?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXclMjB5b3JrJTIwY2l0eSUyMHNreWxpbmV8ZW58MXx8fHwxNzcyODYwNjgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    hotels: "3,214 properties",
  },
  {
    id: 4,
    name: "Dubai",
    country: "UAE",
    image: "https://images.unsplash.com/photo-1682879654288-3bc35430b79f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMGRlc2VydCUyMGx1eHVyeXxlbnwxfHx8fDE3NzI4MzUyODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    hotels: "1,567 properties",
  },
  {
    id: 5,
    name: "London",
    country: "United Kingdom",
    image: "https://images.unsplash.com/photo-1745016176874-cd3ed3f5bfc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsb25kb24lMjBiaWclMjBiZW58ZW58MXx8fHwxNzcyODYxNDU1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    hotels: "2,783 properties",
  },
  {
    id: 6,
    name: "Bali",
    country: "Indonesia",
    image: "https://images.unsplash.com/photo-1599117372066-46efdebe2c42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxpJTIwdGVtcGxlJTIwaXNsYW5kfGVufDF8fHx8MTc3Mjg2NzI4MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    hotels: "1,329 properties",
  },
];

const deals = [
  {
    id: 1,
    title: "Luxury Beach Resort",
    location: "Maldives",
    image: "https://images.unsplash.com/photo-1678687114989-ad452a24f289?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFjaCUyMHJlc29ydCUyMHZhY2F0aW9ufGVufDF8fHx8MTc3Mjg2NzI3OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: "$299",
    originalPrice: "$599",
    discount: "50% off",
    rating: 4.8,
    reviews: 1245,
  },
  {
    id: 2,
    title: "Northern Lights Experience",
    location: "Iceland",
    image: "https://images.unsplash.com/photo-1488415032361-b7e238421f1b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpY2VsYW5kJTIwbm9ydGhlcm4lMjBsaWdodHN8ZW58MXx8fHwxNzcyNzQ1NTU2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: "$189",
    originalPrice: "$349",
    discount: "46% off",
    rating: 4.9,
    reviews: 892,
  },
  {
    id: 3,
    title: "5-Star City Hotel",
    location: "New York",
    image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb218ZW58MXx8fHwxNzcyNzY4ODE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    price: "$219",
    originalPrice: "$459",
    discount: "52% off",
    rating: 4.7,
    reviews: 2134,
  },
];

export function Home() {
  return (
    <div>
      {/* Hero Section */}
      <div
        className="relative bg-cover bg-center h-[500px] flex items-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 59, 149, 0.7), rgba(0, 59, 149, 0.7)), url('https://images.unsplash.com/photo-1565444007614-6b38c78224df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhaXJwbGFuZSUyMGZseWluZyUyMHN1bnNldHxlbnwxfHx8fDE3NzI3NjUwNjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h1 className="text-5xl md:text-6xl mb-4">Explore the world with us</h1>
          <p className="text-xl md:text-2xl mb-8">
            Discover your next adventure at the best prices
          </p>
        </div>
      </div>

      {/* Search Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SearchSection />

        {/* Popular Destinations */}
        <section className="mt-16">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="h-6 w-6 text-[#003b95]" />
            <h2 className="text-3xl">Popular destinations</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {popularDestinations.map((destination) => (
              <Link key={destination.id} to="/hotels">
                <Card className="overflow-hidden hover:shadow-xl transition-shadow cursor-pointer">
                  <div className="relative h-48">
                    <ImageWithFallback
                      src={destination.image}
                      alt={destination.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <h3 className="text-2xl mb-1">{destination.name}</h3>
                      <p className="text-sm opacity-90">{destination.country}</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>{destination.hotels}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Deals */}
        <section className="mt-16">
          <div className="flex items-center gap-2 mb-6">
            <Percent className="h-6 w-6 text-[#003b95]" />
            <h2 className="text-3xl">Today's top deals</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {deals.map((deal) => (
              <Link key={deal.id} to="/hotels">
                <Card className="overflow-hidden hover:shadow-xl transition-shadow cursor-pointer">
                  <div className="relative h-56">
                    <ImageWithFallback
                      src={deal.image}
                      alt={deal.title}
                      className="w-full h-full object-cover"
                    />
                    <Badge className="absolute top-4 right-4 bg-red-500 hover:bg-red-600">
                      {deal.discount}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="text-xl mb-1">{deal.title}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                      <MapPin className="h-4 w-4" />
                      <span>{deal.location}</span>
                    </div>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span>{deal.rating}</span>
                      </div>
                      <span className="text-sm text-gray-500">
                        ({deal.reviews} reviews)
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl text-[#003b95]">{deal.price}</span>
                      <span className="text-sm text-gray-500 line-through">
                        {deal.originalPrice}
                      </span>
                      <span className="text-sm text-gray-600">per night</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Value Propositions */}
        <section className="mt-16 mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Percent className="h-8 w-8 text-[#003b95]" />
              </div>
              <h3 className="text-xl mb-2">Best price guarantee</h3>
              <p className="text-gray-600">
                Find a lower price? We'll refund the difference
              </p>
            </div>
            <div className="text-center p-6">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-[#003b95]" />
              </div>
              <h3 className="text-xl mb-2">Verified reviews</h3>
              <p className="text-gray-600">
                Over 10 million authentic guest reviews
              </p>
            </div>
            <div className="text-center p-6">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-[#003b95]" />
              </div>
              <h3 className="text-xl mb-2">Millions of properties</h3>
              <p className="text-gray-600">
                Hotels, homes, and more in 200+ countries
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
