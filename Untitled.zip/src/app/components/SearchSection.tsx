import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Building2, Plane, Car, Package } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

export function SearchSection() {
  const [activeTab, setActiveTab] = useState("stays");

  return (
    <div className="bg-white rounded-lg shadow-xl p-6 -mt-16 relative z-10 max-w-6xl mx-auto">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="stays" className="flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            <span className="hidden sm:inline">Stays</span>
          </TabsTrigger>
          <TabsTrigger value="flights" className="flex items-center gap-2">
            <Plane className="h-4 w-4" />
            <span className="hidden sm:inline">Flights</span>
          </TabsTrigger>
          <TabsTrigger value="cars" className="flex items-center gap-2">
            <Car className="h-4 w-4" />
            <span className="hidden sm:inline">Cars</span>
          </TabsTrigger>
          <TabsTrigger value="packages" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            <span className="hidden sm:inline">Packages</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="stays">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="destination">Going to</Label>
              <Input
                id="destination"
                placeholder="Where are you going?"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="checkin">Check-in</Label>
              <Input
                id="checkin"
                type="date"
                className="mt-1"
                defaultValue="2026-03-15"
              />
            </div>
            <div>
              <Label htmlFor="checkout">Check-out</Label>
              <Input
                id="checkout"
                type="date"
                className="mt-1"
                defaultValue="2026-03-20"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
            <div>
              <Label htmlFor="travelers">Travelers</Label>
              <Select defaultValue="2">
                <SelectTrigger id="travelers" className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 traveler</SelectItem>
                  <SelectItem value="2">2 travelers</SelectItem>
                  <SelectItem value="3">3 travelers</SelectItem>
                  <SelectItem value="4">4 travelers</SelectItem>
                  <SelectItem value="5">5+ travelers</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-3 flex items-end">
              <Button className="w-full bg-[#003b95] hover:bg-[#002e75]">
                Search
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="flights">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="from">Leaving from</Label>
              <Input
                id="from"
                placeholder="Origin"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="to">Going to</Label>
              <Input
                id="to"
                placeholder="Destination"
                className="mt-1"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
            <div>
              <Label htmlFor="departure">Departing</Label>
              <Input
                id="departure"
                type="date"
                className="mt-1"
                defaultValue="2026-03-15"
              />
            </div>
            <div>
              <Label htmlFor="return">Returning</Label>
              <Input
                id="return"
                type="date"
                className="mt-1"
                defaultValue="2026-03-20"
              />
            </div>
            <div>
              <Label htmlFor="passengers">Travelers</Label>
              <Select defaultValue="1">
                <SelectTrigger id="passengers" className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 traveler</SelectItem>
                  <SelectItem value="2">2 travelers</SelectItem>
                  <SelectItem value="3">3 travelers</SelectItem>
                  <SelectItem value="4">4+ travelers</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button className="w-full bg-[#003b95] hover:bg-[#002e75]">
                Search flights
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="cars">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="pickup">Pick-up location</Label>
              <Input
                id="pickup"
                placeholder="City, airport, address or hotel"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="dropoff">Drop-off location</Label>
              <Input
                id="dropoff"
                placeholder="Same as pick-up"
                className="mt-1"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
            <div>
              <Label htmlFor="pickupdate">Pick-up date</Label>
              <Input
                id="pickupdate"
                type="date"
                className="mt-1"
                defaultValue="2026-03-15"
              />
            </div>
            <div>
              <Label htmlFor="dropoffdate">Drop-off date</Label>
              <Input
                id="dropoffdate"
                type="date"
                className="mt-1"
                defaultValue="2026-03-20"
              />
            </div>
            <div className="md:col-span-2 flex items-end">
              <Button className="w-full bg-[#003b95] hover:bg-[#002e75]">
                Search cars
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="packages">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="pkgdest">Going to</Label>
              <Input
                id="pkgdest"
                placeholder="Where do you want to go?"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="pkgtype">Package type</Label>
              <Select defaultValue="flight-hotel">
                <SelectTrigger id="pkgtype" className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="flight-hotel">Flight + Hotel</SelectItem>
                  <SelectItem value="flight-hotel-car">Flight + Hotel + Car</SelectItem>
                  <SelectItem value="hotel-car">Hotel + Car</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
            <div>
              <Label htmlFor="pkgcheckin">Check-in</Label>
              <Input
                id="pkgcheckin"
                type="date"
                className="mt-1"
                defaultValue="2026-03-15"
              />
            </div>
            <div>
              <Label htmlFor="pkgcheckout">Check-out</Label>
              <Input
                id="pkgcheckout"
                type="date"
                className="mt-1"
                defaultValue="2026-03-20"
              />
            </div>
            <div>
              <Label htmlFor="pkgtravelers">Travelers</Label>
              <Select defaultValue="2">
                <SelectTrigger id="pkgtravelers" className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 traveler</SelectItem>
                  <SelectItem value="2">2 travelers</SelectItem>
                  <SelectItem value="3">3 travelers</SelectItem>
                  <SelectItem value="4">4+ travelers</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button className="w-full bg-[#003b95] hover:bg-[#002e75]">
                Search packages
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
