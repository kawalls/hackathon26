import { Link } from "react-router";
import { Plane, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-100 border-t border-gray-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Company */}
          <div>
            <h3 className="font-semibold mb-4">Company</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/" className="hover:text-[#003b95]">About us</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Jobs</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">List your property</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Partnerships</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Newsroom</Link></li>
            </ul>
          </div>

          {/* Explore */}
          <div>
            <h3 className="font-semibold mb-4">Explore</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/hotels" className="hover:text-[#003b95]">Hotels</Link></li>
              <li><Link to="/flights" className="hover:text-[#003b95]">Flights</Link></li>
              <li><Link to="/deals" className="hover:text-[#003b95]">Car rentals</Link></li>
              <li><Link to="/deals" className="hover:text-[#003b95]">Vacation packages</Link></li>
              <li><Link to="/deals" className="hover:text-[#003b95]">Travel guides</Link></li>
            </ul>
          </div>

          {/* Policies */}
          <div>
            <h3 className="font-semibold mb-4">Policies</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/" className="hover:text-[#003b95]">Privacy</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Terms of use</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Accessibility</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Your privacy choices</Link></li>
            </ul>
          </div>

          {/* Help */}
          <div>
            <h3 className="font-semibold mb-4">Help</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link to="/" className="hover:text-[#003b95]">Support</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Cancel your booking</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Use a coupon</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Refund policies</Link></li>
              <li><Link to="/" className="hover:text-[#003b95]">Contact us</Link></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="font-semibold mb-4">Travel deals</h3>
            <p className="text-sm text-gray-600 mb-4">
              Get exclusive offers and travel inspiration delivered to your inbox
            </p>
            <div className="flex gap-2 mb-4">
              <input
                type="email"
                placeholder="Email address"
                className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#003b95]"
              />
              <button className="bg-[#003b95] text-white px-4 py-2 rounded hover:bg-[#002e75] transition">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-12 pt-8 border-t border-gray-300 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <Plane className="h-6 w-6 text-[#003b95]" />
            <span className="font-bold text-[#003b95]">TravelHub</span>
          </div>

          <div className="flex items-center gap-4">
            <Link to="/" className="text-gray-600 hover:text-[#003b95] transition">
              <Facebook className="h-5 w-5" />
            </Link>
            <Link to="/" className="text-gray-600 hover:text-[#003b95] transition">
              <Twitter className="h-5 w-5" />
            </Link>
            <Link to="/" className="text-gray-600 hover:text-[#003b95] transition">
              <Instagram className="h-5 w-5" />
            </Link>
            <Link to="/" className="text-gray-600 hover:text-[#003b95] transition">
              <Linkedin className="h-5 w-5" />
            </Link>
          </div>

          <p className="text-sm text-gray-600">
            © 2026 TravelHub. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
