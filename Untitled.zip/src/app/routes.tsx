import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { Home } from "./components/Home";
import { Hotels } from "./components/Hotels";
import { Flights } from "./components/Flights";
import { Deals } from "./components/Deals";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "hotels", Component: Hotels },
      { path: "flights", Component: Flights },
      { path: "deals", Component: Deals },
    ],
  },
]);
